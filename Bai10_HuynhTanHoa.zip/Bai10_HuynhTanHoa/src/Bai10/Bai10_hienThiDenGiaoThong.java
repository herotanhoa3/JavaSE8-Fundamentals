/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai10;

/**
 *
 * @author hocvien
 */
public class Bai10_hienThiDenGiaoThong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("đèn " + DenGiaoThong.XANH.toString() + " chuyển qua đèn " + DenGiaoThong.XANH.chuyenDen().toString() + " với " + DenGiaoThong.XANH.giay() + " giây");
        System.out.println("đèn " + DenGiaoThong.DO.toString() + " chuyển qua đèn " + DenGiaoThong.DO.chuyenDen().toString() + " với " + DenGiaoThong.DO.giay() + " giây");
        System.out.println("đèn " + DenGiaoThong.VANG.toString() + " chuyển qua đèn " + DenGiaoThong.VANG.chuyenDen().toString() + " với " + DenGiaoThong.VANG.giay() + " giây");
        
    }
    
}
enum DenGiaoThong {
        XANH,
        VANG,
        DO;

        int giay() {
            switch (this) {
                case XANH:
                    return 30;
                case DO:
                    return 40;
                default:
                    return 10;
            }
        }

        DenGiaoThong chuyenDen() {
            switch (this) {
                case XANH:
                    return VANG;
                case DO:
                    return XANH;
                default:
                    return DO;
            }
        }

        @Override
        public String toString() {
            switch (this) {
                case XANH:
                    return "Xanh";
                case DO:
                    return "Đỏ";
                default:
                    return "Vàng";
            }
        }
    }