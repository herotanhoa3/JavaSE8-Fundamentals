/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import Bai14.bai14_8_3;

/**
 *
 * @author hocvien
 */
public class Test14_8_3 {
    
    public Test14_8_3() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
   @Test
    public void test1() {
        double ac=bai14_8_3.tinhGiaiThuc(5);
        double ex=120;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test2() {
        double ac=bai14_8_3.tinhGiaiThuc(10);
        double ex=3628800;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test3() {
        double ac=bai14_8_3.tinhGiaiThuc(8);
        double ex=40320;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test4() {
        double ac=bai14_8_3.tinhGiaiThuc(0);
        double ex=1;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test5() {
        double ac=bai14_8_3.tinhGiaiThuc(4);
        double ex=24;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test6() {
        double ac=bai14_8_3.tinhGiaiThuc(5);
        double ex=100;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test7() {
        double ac=bai14_8_3.tinhGiaiThuc(10);
        double ex=800;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test8() {
        double ac=bai14_8_3.tinhGiaiThuc(8);
        double ex=4000;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test9() {
        double ac=bai14_8_3.tinhGiaiThuc(0);
        double ex=0;
        assertEquals(ex, ac, 0.1);
    }
    @Test
    public void test10() {
        double ac=bai14_8_3.tinhGiaiThuc(4);
        double ex=30;
        assertEquals(ex, ac, 0.1);
    }
}
