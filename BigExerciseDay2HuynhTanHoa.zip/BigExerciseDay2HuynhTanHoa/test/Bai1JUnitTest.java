/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai1JUnitTest {

    public Bai1JUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void TestBai1_01() {
        double ex =8000;
        double ac = Bai1.tinhCuocHinhThuc1(1,40, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai1_02() {
        double ex =510000;
        double ac = Bai1.tinhCuocHinhThuc1(2,3500, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai1_03() {
        double ex =50000;
        double ac = Bai1.tinhCuocHinhThuc1(2,140, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai1_04() {
        double ex =500000;
        double ac = Bai1.tinhCuocHinhThuc1(3,600, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
     @Test
    public void TestBai1_05() {
        double ex =50000;
        double ac = Bai1.tinhCuocHinhThuc1(3,140, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
     @Test
    public void TestBai1_06() {
        double ex =50000;
        double ac = Bai1.tinhCuocHinhThuc1(3,8000, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
     @Test
    public void TestBai1_07() {
        double ex =500002;
        double ac = Bai1.tinhCuocHinhThuc1(3,1400, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai1_08() {
        double ex =5902;
        double ac = Bai1.tinhCuocHinhThuc1(1,2000, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    } 
    @Test
    public void TestBai1_09() {
        double ex =0;
        double ac = Bai1.tinhCuocHinhThuc1(1,2000, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai1_10() {
        double ex =8000;
        double ac = Bai1.tinhCuocHinhThuc1(1,70, 1, 1, 1);
        assertEquals(ex, ac,0.01);
    }
    
    
}
