/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai14.Bai14_6;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai14_6JUnitTest {
    
    public Bai14_6JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test14_6_01() {
        boolean ac = Bai14_6.ktSoNT(2);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_02() {
        boolean ac = Bai14_6.ktSoNT(11);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_03() {
        boolean ac = Bai14_6.ktSoNT(13);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_04() {
        boolean ac = Bai14_6.ktSoNT(18);
        assertFalse(ac);
    }
    @Test
    public void Test14_6_05() {
        boolean ac = Bai14_6.ktSoNT(20);
        assertFalse(ac);
    }
    @Test
    public void Test14_6_06() {
        boolean ac = Bai14_6.ktSoNT(234);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_07() {
        boolean ac = Bai14_6.ktSoNT(92);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_08() {
        boolean ac = Bai14_6.ktSoNT(91);
        assertTrue(ac);
    }
    @Test
    public void Test14_6_09() {
       boolean ac = Bai14_6.ktSoNT(31);
        assertFalse(ac);
    }
    @Test
    public void Test14_6_10() {
        boolean ac = Bai14_6.ktSoNT(41);
        assertFalse(ac);
    }
}
