
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai2 {

    static Scanner input = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        nhapLieu();
    }

    public static void nhapLieu() {
        System.out.println("Nhap so m3 nuoc da dung: ");
        double m3 = input.nextInt();
        double soNguoi = 0;
        int loai = 0;
        System.out.println("Chon doi tuong sinh hoat (1)/ khong sinh hoat (2)");
        int doiTuong = input.nextInt();
        if (doiTuong == 1) {
            System.out.println("Nhap so nguoi sinh hoat trong gia dinh: ");
            soNguoi = input.nextInt();
        } else if (doiTuong == 2) {
            System.out.println("Chon loai: ");
            System.out.println("Don vi san xuat (1)/ Co quan, doan the (2)/ Don vi kinh doanh (3)");
            loai = input.nextInt();
        }
        tinhTienNuoc(m3, doiTuong, soNguoi, loai);
    }

    public static double tinhTienNuoc(double m3, int doiTuong, double soNguoi, int loai) {
        double kiemTra = m3 / soNguoi;
        double tienNuocKhongThue = 5300, tienNuocKhongThue1 = 10200, tienNuocKhongThue2 = 11400;
        double tienNuocKTSanXuat = 9600, tienNuocKTCoQuan = 10300, tienNuocKTKinhDoanh = 16900;
        double tienThue = 265, tienThue1 = 510, tienThue2 = 570;
        double tienThueSanXuat = 480, tienThueCoQuan = 515, tienThueKinhDoanh = 845;
        double phiBVMT = 530, phiBVMT1 = 1020, phiBVMT2 = 1140;
        double phiBVMTSanXuat = 960, phiBVMTCoQuan = 1030, phiBVMTKinhDoanh = 1690;
        double tongTienNuocKhongThue = 0, tongTienThue = 0, tongPhiBVMT = 0;
        double tongTien = 0;
        switch (doiTuong) {
            case 1:
                if (kiemTra <= 4) {
                    tongTienNuocKhongThue = kiemTra * tienNuocKhongThue * soNguoi;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                } else if (kiemTra <= 6) {
                    tongTienNuocKhongThue = 4 * tienNuocKhongThue * soNguoi + (kiemTra - 4) * tienNuocKhongThue1 * soNguoi;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                } else if (kiemTra > 6) {
                    tongTienNuocKhongThue = 4 * tienNuocKhongThue * soNguoi + 2 * tienNuocKhongThue1 * soNguoi + (kiemTra - 6) * tienNuocKhongThue2 * soNguoi;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                }break;
            case 2:
                if (loai == 1) {
                    tongTienNuocKhongThue = m3 * tienNuocKTSanXuat;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                } else if (loai == 2) {
                    tongTienNuocKhongThue = m3 * tienNuocKTCoQuan;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                } else if (loai == 3) {
                    tongTienNuocKhongThue = m3 * tienNuocKTKinhDoanh;
                    tongTienThue = tongTienNuocKhongThue * 0.05;
                    tongPhiBVMT = tongTienNuocKhongThue * 0.1;
                    tongTien = tongTienNuocKhongThue + tongTienThue + tongPhiBVMT;
                    System.out.println("Tong so m3: " + m3);
                    System.out.println("Tien nuoc khong thue va phi: " + tongTienNuocKhongThue);
                    System.out.println("Tien thue GTGT: " + tongTienThue);
                    System.out.println("Tien phi BVMT: " + tongPhiBVMT);
                    System.out.println("Tong tien phai tra: " + tongTien);
                }break;
            default:
                System.err.println("Nhap sai doi tuong!!");
                break;
        }
        return tongTien;
    }

}
