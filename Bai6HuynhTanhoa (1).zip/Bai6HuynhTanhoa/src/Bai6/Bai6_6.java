/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        int[][] arr = new int[n][n];
        int sumPaddle = 0;
        int maxPaddle = 0;
        int minPaddle = 0;
        boolean flag = true;
        Random random = new Random();
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                arr[i][j] = random.nextInt(20);
                System.out.print(arr[i][j] + " ");
                if (i == 0 && j == 0) {
                    maxPaddle = minPaddle = arr[i][j];
                }
                if (i == j) {
                    sumPaddle += arr[i][j];
                    maxPaddle = Math.max(maxPaddle, arr[i][j]);
                    minPaddle = Math.min(maxPaddle, arr[i][j]);
                }
//                for (int z = 2; z < arr[i][j]/2; i++) {
//                    if (arr[i][j] % z == 0) {
//                        flag = false;
//                    }
//                }
//                if (flag == true) {
//                     System.out.println("La so nguyen to: " + maxPaddle);
//                }
            }
            System.out.println();
        }
        System.out.println("Tong cac gia tri tren duong cheo: " + sumPaddle);
        System.out.println("Gia tri nho nhat: " + minPaddle);
        System.out.println("Gia tri lon nhat: " + maxPaddle);
        
    }

}
