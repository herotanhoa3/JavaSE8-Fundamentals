/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai3JUnitTest {
    
    public Bai3JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void TestBai3_01() {
        int[][] mang = {{1,2,3},{4,5,6},{7,8,9}};
        double ex = 10;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_02() {
        int[][] mang = {{3,7,0},{2,5,9},{2,4,6}};
        double ex = 11;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_03() {
        int[][] mang = {{2,4,1},{4,-6,-6},{-2,-8,-9}};
        double ex = -4;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_04() {
        int[][] mang = {{1,-2,6},{1,-5,6},{2,-8,9}};
        double ex = -10;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_06() {
        int[][] mang = {{7,2,7},{4,9,6},{4,8,9}};
        double ex = -10;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_07() {
        int[][] mang = {{2,4,1},{4,-6,-6},{-2,-8,-9}};
        double ex = 4;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_08() {
        int[][] mang = {{1,-2,6},{1,-5,6},{2,-8,9}};
        double ex = 10;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_05() {
        int[][] mang = {{7,2,7},{4,9,6},{4,8,9}};
        double ex = 10;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_09() {
        int[][] mang = {{3,7,0},{2,5,9},{2,4,6}};
        double ex = -11;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai3_10() {
        int[][] mang = {{2,4,1},{4,-6,-6},{-2,-8,-9}};
        double ex = 5;
        double ac = Bai3.tinhTongPT(mang);
        assertEquals(ex, ac,0.01);
    }
}
