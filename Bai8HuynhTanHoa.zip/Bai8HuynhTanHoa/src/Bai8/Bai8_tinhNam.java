/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_tinhNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Scanner input = new Scanner(System.in);
            System.out.println("Nhap nam sinh:");
            int year = input.nextInt();
            System.out.println(tinhCan(year) + " " + tinhChi(year));
        } catch (ArithmeticException | IllegalArgumentException  e) {
           
            System.out.println("Loi: " + e.toString());
        }
    }

    static String tinhCan(int year) {
        switch (year % 10) {
            case 0:
                return "Canh";
            case 1:
                return "Tan";
            case 2:
                return "Nham";
            case 3:
                return "Quy";
            case 4:
                return "Giap";
            case 5:
                return "At";
            case 6:
                return "Binh";
            case 7:
                return "Dinh";
            case 8:
                return "Mau";
            case 9:
                return "Ky";
            default:
                return "";
        }
    }

    static String tinhChi(int year) {
        switch (year % 12) {
            case 0:
                return "Than";
            case 1:
                return "Dau";
            case 2:
                return "Tuat";
            case 3:
                return "Hoi";
            case 4:
                return "Ty";
            case 5:
                return "Suu";
            case 6:
                return "Dan";
            case 7:
                return "Mao";
            case 8:
                return "Thin";
            case 9:
                return "Ty";
            case 10:
                return "Ngo";
            case 11:
                return "Mui";
        }
        return "";
    }
    
}
