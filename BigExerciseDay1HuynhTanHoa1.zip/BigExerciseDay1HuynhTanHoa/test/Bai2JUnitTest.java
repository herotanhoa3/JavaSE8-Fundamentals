/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import BigExerciseDay1.Bai2;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai2JUnitTest {
    
    public Bai2JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
   @Test
    public void testBai2_01() {
        int[][] maTranVuong = {{1,2,3},{4,3,6},{7,8,9}};
        int ex = 7;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_02() {
        int[][] maTranVuong = {{6,2,2},{-8,2,1},{10,11,12}};
        int ex = 10;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_03() {
        int[][] maTranVuong = {{12,12,83},{44,33,26},{17,15,9}};
        int ex = 9;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_04() {
        int[][] maTranVuong = {{66,52,24},{28,23,21},{410,211,312}};
        int ex = 211;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_05() {
        int[][] maTranVuong = {{122,123,483},{454,373,826},{197,105,-9}};
        int ex = -9;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_06() {
        int[][] maTranVuong = {{66,52,24},{28,23,21},{410,211,312}};
        int ex = 211;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_07() {
        int[][] maTranVuong = {{122,123,483},{454,373,826},{197,105,-9}};
        int ex = -9;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    public void testBai2_08() {
        int[][] maTranVuong = {{606,502,240},{208,203,201},{4110,2101,3102}};
        int ex = 2101;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_09() {
        int[][] maTranVuong = {{12,13,43},{44,73,82},{17,15,-9}};
        int ex = -9;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai2_10() {
        int[][] maTranVuong = {{22,13,48},{45,33,86},{17,15,-19}};
        int ex = -19;
        int ac = Bai2.timMin(maTranVuong);
        assertEquals(ex, ac);
    }
    
    
    
}
