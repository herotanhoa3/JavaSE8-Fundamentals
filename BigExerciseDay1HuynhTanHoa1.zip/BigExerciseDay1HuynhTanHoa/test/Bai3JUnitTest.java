/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import BigExerciseDay1.Bai3;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai3JUnitTest {

    public Bai3JUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testBai3_01() {
        double ex = 387000;
        double ac = Bai3.tinhTienVe(4, 2, 2, 0, 129000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_02() {
        double ex = 654000;
        double ac = Bai3.tinhTienVe(5, 0, 3, 2, 218000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_03() {
        double ex = 1197000;
        double ac = Bai3.tinhTienVe(10, 3, 5, 2, 171000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_04() {
        double ex = 903000;
        double ac = Bai3.tinhTienVe(6, 3, 0, 3, 172000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_05() {
        double ex = 618750;
        double ac = Bai3.tinhTienVe(10, 2, 7, 1, 99000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_06() {
        double ex = 500000;
        double ac = Bai3.tinhTienVe(10, 2, 7, 1, 249000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_07() {
        double ex = 950000;
        double ac = Bai3.tinhTienVe(8, 2, 5, 1, 163000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_08() {
        double ex = 1500000;
        double ac = Bai3.tinhTienVe(12, 2, 5, 1, 163000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_09() {
        double ex = 950000;
        double ac = Bai3.tinhTienVe(8, 2, 5, 1, 168000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai3_10() {
        double ex = 950000;
        double ac = Bai3.tinhTienVe(8, 2, 5, 1, 146000);
        assertEquals(ex, ac, 0.01);
    }


}
