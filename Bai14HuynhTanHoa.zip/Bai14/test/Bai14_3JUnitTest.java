/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai14.Bai14_3;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai14_3JUnitTest {
    
    public Bai14_3JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Test14_3_01() {
        int[] a =  {9,5,1,7,5};
        boolean ac = Bai14_3.timX(5,a);
        assertTrue(ac);
    }
    @Test
    public void Test14_3_02() {
        int[] a = {9,1,2,3,4};
        boolean ac = Bai14_3.timX(9,a);
        assertTrue(ac);
    }
    @Test
    public void Test14_3_03() {
        int[] a =  {99,100,21,1,-3};
        boolean ac = Bai14_3.timX(2,a);
        assertFalse(ac);
    }
    @Test
    public void Test14_3_04() {
        int[] a =  {-2,-5,0,2,6};
        boolean ac = Bai14_3.timX(1,a);
        assertFalse(ac);
    }
    @Test
    public void Test14_3_05() {
        int[] a =  {2,3,4,5,200};
        boolean ac = Bai14_3.timX(0,a);
        assertFalse(ac);
    }
    @Test
    public void Test14_3_06() {
        int[] a =  {33,23,45,73,2};
        boolean ac = Bai14_3.timX(44,a);
        assertTrue(ac);
    }
    @Test
    public void Test14_3_07() {
        int[] a = {12,34,23,52,6};
        boolean ac = Bai14_3.timX(98,a);
        assertTrue(ac);
    }
    @Test
    public void Test14_3_08() {
        int[] a =  {-12,3,-34,21};
        boolean ac = Bai14_3.timX(3,a);
        assertFalse(ac);
    }
    @Test
    public void Test14_3_09() {
        int[] a =  {-213,21,34,-67,-53};
        boolean ac = Bai14_3.timX(-67,a);
        assertFalse(ac);
    }
    @Test
    public void Test14_3_10() {
        int[] a =  {-6,-2,-7,-8,-9};
        boolean ac = Bai14_3.timX(-7,a);
        assertFalse(ac);
    }
}
