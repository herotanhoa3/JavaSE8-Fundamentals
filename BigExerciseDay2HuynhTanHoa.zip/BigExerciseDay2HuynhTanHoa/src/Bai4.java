
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai4 {

    public static Scanner input = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        nhapLieu();
    }

    public static void nhapLieu() {
        System.out.println("Enter the number of students: ");

        int n = input.nextInt();
        int[] mang = new int[n];
        for (int i = 0; i < mang.length; i++) {
            do {
                System.out.println("Enter the grade for students " + (i + 1) + " :");
                mang[i] = input.nextInt();
            } while (mang[i] < 0 || mang[i] > 10);
        }
        System.out.println("The average is: " + tinhDiemTB(mang, n));
        System.out.println("The maximum is: " + timMax(mang, n));
        System.out.println("The minimum is: " + timMin(mang, n));
        
    }

    public static double tinhDiemTB(int[] mang, int n) {
        double diemTB = 0;
        for (int i = 0; i < mang.length; i++) {
            diemTB += mang[i];
        }
        return diemTB / n;
    }

    public static int timMax(int[] mang, int n) {
        int max = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i == 0) {
                max = mang[i];
            } else if (mang[i] > max) {
                max = mang[i];
            }
        }
        return max;
    }

    public static int timMin(int[] mang, int n) {
        int min = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i == 0) {
                min = mang[i];
            } else if (mang[i] < min) {
                min = mang[i];
            }
        }
        return min;
    }
}
