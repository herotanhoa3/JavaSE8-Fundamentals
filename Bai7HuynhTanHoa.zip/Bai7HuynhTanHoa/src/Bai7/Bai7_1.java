/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        System.out.println("Nhap x:");
        double x = input.nextDouble();
        System.out.println("S = (x * x + 1) mu " + n + "= " + tinhS(n, x));
    }

    public static double tinhS(int n, double x) {
        double S = 1;
        for (int i = 0; i < n; i++) {
            S *= (x * x + 1);
        }
        return S;
    }

}
