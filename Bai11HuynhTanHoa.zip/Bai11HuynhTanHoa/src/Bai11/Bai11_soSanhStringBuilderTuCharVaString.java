/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_soSanhStringBuilderTuCharVaString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        StringBuilder s1 = new StringBuilder();
        StringBuilder s2 = new StringBuilder();
        long thoiGians1BD = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            char x = 'A';
            s1.append(x );
        }
        long thoiGians1KT = System.currentTimeMillis();
        long thoiGians2BD = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            String x = "A";
            s2.append(x);
        }
        long thoiGians2KT = System.currentTimeMillis();
        System.out.println("Chieu dai chuoi String sb1: " + s1.length());
        System.out.println("Chieu dai chuoi String sb1: " + s2.length());
        System.out.println("Thoi gian thuc hien sb1: " + (thoiGians1KT - thoiGians1BD));
        System.out.println("Thoi gian thuc hien sb2: " + (thoiGians2KT - thoiGians2BD));
        if ((thoiGians1KT - thoiGians1BD) < (thoiGians2KT - thoiGians2BD)) {
            System.out.println("Thoi gian String dai hon char");
        } else {
            System.out.println("Thoi gian char dai hon String");
        }
    }

}
