/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai10;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai10_playOneTwoThree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        boolean flag = false;
        System.out.println("Chọn s để bắt đầu");
        String x = input.nextLine();
        if (x.equalsIgnoreCase("s")) {
            flag = true;
        }
        Games may;
        Games nguoichoi;
        int diemmay = 0;
        int diemnguoichoi = 0;
        int vongChoi = 1;
        while (flag) {
            System.out.println("*******************************************");
            System.out.println("Bạn đang ở vòng: "+vongChoi);
            System.out.println("Chọn q, s, p, t");
            String z = input.nextLine();
            if (z.equalsIgnoreCase("q")) {
                System.out.println("Bạn đã dừng chương trình");
                System.out.println("Điểm máy: " + diemmay);
                System.out.println("Điểm người chơi: " + diemnguoichoi);
                break;
            } else if (z.equalsIgnoreCase("s")) {
                nguoichoi = Games.SCISSOR;
                System.out.println("Bạn đã chọn: " + nguoichoi.SCISSOR.name());
            } else if (z.equalsIgnoreCase("p")) {
                nguoichoi = Games.PAPER;
                System.out.println("Bạn đã chọn: " + nguoichoi.PAPER.name());
            } else if (z.equalsIgnoreCase("t")) {
                nguoichoi = Games.STONE;
                System.out.println("Bạn đã chọn: " + nguoichoi.STONE.name());
            } else {
                System.out.println("Bạn đã nhập sai");
                continue;
            }
            int temp = randomPC();
            if (temp == 0) {
                may = Games.SCISSOR;
                System.out.println("Máy đã chọn: " + may.SCISSOR.name());
            } else if (temp == 1) {
                may = Games.PAPER;
                System.out.println("Máy đã chọn: " + may.PAPER.name());
            } else {
                may = Games.STONE;
                System.out.println("Máy đã chọn: " + may.STONE.name());
            }
            if (may.Choose(nguoichoi) == 0) {
                System.out.println("Kết quả hòa");
                System.out.println("Điểm máy: " + diemmay);
                System.out.println("Điểm người chơi: " + diemnguoichoi);
            } else if (may.Choose(nguoichoi) == 1) {
                System.out.println("Bạn đã thắng");
                diemnguoichoi++;
                System.out.println("Điểm máy: " + diemmay);
                System.out.println("Điểm người chơi: " + diemnguoichoi);
            } else {
                System.out.println("Bạn đã thua");
                diemmay++;
                System.out.println("Điểm máy: " + diemmay);
                System.out.println("Điểm người chơi: " + diemnguoichoi);
            }
            if (diemmay == 5 || diemnguoichoi == 5) {
                System.out.println("Lượt chơi kết thúc");
                System.out.println("Điểm máy: " + diemmay);
                System.out.println("Điểm người chơi: " + diemnguoichoi);
                if (diemmay > diemnguoichoi) {
                    System.out.println("Bạn đã thua");
                } else {
                    System.out.println("Bạn đã thắng");
                }
                flag = false;
            }
            vongChoi++;
        }

    }

    static int randomPC() {
        Random random = new Random();
        int n = 0;
        n = random.nextInt(3);

        return n;

    }
}

enum Games {
    SCISSOR,
    PAPER,
    STONE;

    int Choose(Games nguoichoi) {
        switch (this) {
            case SCISSOR:
                if (nguoichoi.equals(this)) {
                    return 0;
                } else if (nguoichoi.equals(PAPER)) {
                    return 2;
                } else {
                    return 1;
                }
            case PAPER:
                if (nguoichoi.equals(this)) {
                    return 0;
                } else if (nguoichoi.equals(STONE)) {
                    return 2;
                } else {
                    return 1;
                }
            case STONE:
                if (nguoichoi.equals(this)) {
                    return 0;
                } else if (nguoichoi.equals(SCISSOR)) {
                    return 2;
                } else {
                    return 1;
                }
            default:
                throw new AssertionError("Unknown operators" + this);
        }
    }
}
