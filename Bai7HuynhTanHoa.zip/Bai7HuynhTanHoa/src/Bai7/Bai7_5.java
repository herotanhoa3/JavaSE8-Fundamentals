/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao can nang: ");
        double canNang= input.nextDouble();
        System.out.println("Nhap vao chieu cao: ");
        double chieuCao= input.nextDouble();
        danhGiaBMI(tinhBMI(canNang, chieuCao));
    }

    public static double tinhBMI(double canNang, double chieuCao) {
        double BMI = canNang / (chieuCao * chieuCao);
        return BMI;
    }

    public static void danhGiaBMI(double BMI) {
        if (BMI < 18.5) {
            System.out.println("BMI = "+String.format("%.0f", BMI)+" - Ket luan: Ban gay < 18.5 ");
        }
        else if (BMI <= 24.99) {
            System.out.println("BMI = "+String.format("%.0f", BMI)+" - Ket luan: Ban binh thuong 18.5 - 24.99");
        } else {
            System.out.println("BMI = "+String.format("%.0f", BMI)+" - Ket luan: Ban thua can >= 25");
        }
    }
}
