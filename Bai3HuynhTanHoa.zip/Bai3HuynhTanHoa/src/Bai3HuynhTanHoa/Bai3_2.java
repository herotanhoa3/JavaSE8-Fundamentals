/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai3HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai3_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao x: ");
        double x= input.nextDouble();
        double kq = 1+x+ x*x*x/3 + x*x*x*x*x/5;
        System.out.println("Ket qua S= "+String.format("%.1f", kq));
    }
    
}
