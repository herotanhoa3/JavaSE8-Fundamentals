/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        String m = inp.readLine();
        int n = Integer.parseInt(m);
        mangMotChieu(n);
    }

    public static void mangMotChieu(int n) {
        Scanner input = new Scanner(System.in);
        int[] arr = new int[n];
        boolean checkIncre = true;
        boolean checkDecre = true;
        int phanTu = 0;
        System.out.println("Nhap vao " + n + " phan tu:");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = input.nextInt();
        }
        System.out.println("Mang da nhap:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i + 1] < arr[i]) {
                checkIncre = false;
            }
            if (arr[i + 1] > arr[i]) {
                checkDecre = false;
            }

        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 10 == 6 || arr[i] % 6 == 0) {
                phanTu = arr[i];
                break;
            }
        }
        System.out.println();
        if (checkIncre == false) {
            System.out.println("mang khong sap thu tu tang dan");
        } else {
            System.out.println("mang sap thu tu tang dan");
        }
        if (checkDecre == false) {
            System.out.println("mang khong sap thu tu giam dan");
        } else {
            System.out.println("mang sap thu tu giam dan");
        }
        System.out.println(phanTu + " la phan tu dau tien chia het cho 6");
    }
    
}
