/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.io.BufferedReader;
import java.util.Scanner;

/**
 *
 * @author huynh
 */
public class doiNhiPhan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        String S = "";
        //doi Nhi Phan
        for (; n > 0; n = n / 2) {
            S += n % 2;
        }
        String reverse= new StringBuffer(S).reverse().toString();
        System.out.println("So thap phan "+n+" = So nhi phan:"+reverse+"");
    }

}
