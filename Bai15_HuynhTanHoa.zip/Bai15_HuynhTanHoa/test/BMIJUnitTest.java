/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai15.BMI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class BMIJUnitTest {

    BMI bmi = new BMI();

    public BMIJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void bMI1() {
        double ex = 18.73;
        double ac = bmi.chiSoBMI(1.55, 45);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void bMI2() {
        double ex = 19.53125;
        double ac = bmi.chiSoBMI(1.6, 50);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI3() {
        double ex = 20.20;
        double ac = bmi.chiSoBMI(1.65, 55);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI4() {
        double ex = 20.761246;
        double ac = bmi.chiSoBMI(1.7, 60);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI5() {
        double ex = 21.20;
        double ac = bmi.chiSoBMI(1.75, 65);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI6() {
        double ex = 13.333333;
        double ac = bmi.chiSoBMI(1.5, 30);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI7() {
        double ex = 16.17;
        double ac = bmi.chiSoBMI(1.45, 34);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI8() {
        double ex = 20.41;
        double ac = bmi.chiSoBMI(1.4, 40);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI9() {
        double ex = 13.71;
        double ac = bmi.chiSoBMI(1.35, 25);
        assertEquals(ex, ac, 0.01);
    }
     @Test
    public void bMI10() {
        double ex = 11.83432;
        double ac = bmi.chiSoBMI(1.3, 20);
        assertEquals(ex, ac, 0.01);
    }
}
