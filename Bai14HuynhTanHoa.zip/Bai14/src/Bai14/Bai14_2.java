/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai14;

/**
 *
 * @author hocvien
 */
public class Bai14_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static double tinhA(int n, double x) {
        double varA = 1, varB = 1, A = 1;
        for (int i = 1; i <= n; i++) {
            varA *= (x * x + x + 1);
            varB *= (x * x - x + 1);
            A = varA + varB;
        }
        return A;
    }
}
