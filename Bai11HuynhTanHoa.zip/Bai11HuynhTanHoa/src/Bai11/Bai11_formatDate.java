/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai11_formatDate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        formatDate();
    }

    static void formatDate() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao ngay thang nam: ");
        String check = input.nextLine();
        Pattern p = Pattern.compile("(^(0?[1-9]|[12][0-9]|3[01])[\\/](0?[1-9]|1[012])[\\/]\\d{4}$)");
        Matcher m1 = p.matcher(check);
        boolean r1 = m1.matches();
        if (r1 == true) {
            System.out.println("Ngay hop le: " + r1);
        } else {
            System.out.println("Ngay khong hop le: " + r1);
        }
    }
}
