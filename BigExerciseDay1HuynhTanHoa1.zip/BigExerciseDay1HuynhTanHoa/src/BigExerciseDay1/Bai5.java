/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        int n = input.nextInt();
        int[] mang = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            mang[i] = random.nextInt(n);
        }
        System.out.println("Mang mot chieu la: ");
        for (int i = 0; i < n; i++) {
            System.out.print(mang[i] + " ");
        }
        System.out.println();
        mangHaiChieu(mang);

    }

    static void mangHaiChieu(int[] mang) {
        String[][] maTran = new String[mang.length][mang.length];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                maTran[i][mang[i]] = "Q ";
                if (maTran[i][j] == null) {
                    maTran[i][j] = "* ";
                }
            }
        }
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                System.out.print(maTran[i][j]+ "");
            }
            System.out.println("");
        }

    }
}
