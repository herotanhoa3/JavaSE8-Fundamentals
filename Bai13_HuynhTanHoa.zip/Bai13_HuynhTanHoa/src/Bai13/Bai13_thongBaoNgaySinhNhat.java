/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai13;

import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai13_thongBaoNgaySinhNhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        thongBaoSinhNhat();
    }

    static void thongBaoSinhNhat() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap ngay sinh nhat theo dinh dang: dd/MM/yyyy");
        String ngaySinhNhat = input.nextLine();
        String[] days = ngaySinhNhat.split("/");
        LocalDate homNay = LocalDate.now();
        LocalDate sinhNhat = LocalDate.of(homNay.getYear(), Integer.parseInt(days[1]), Integer.parseInt(days[0]));
        Period p = Period.between(homNay, sinhNhat);
        if (p.getMonths() == 0 && p.getDays() == 0) {
            System.out.println("Happy birthday to you!");
        } else if (p.getMonths() > 0 || (p.getMonths() == 0 && p.getDays() > 0)) {
            System.out.println("Please waiting for you...");
        } else if (p.getDays() < 0) {
             System.out.println("See you next birthday...");
        }
    }
}
