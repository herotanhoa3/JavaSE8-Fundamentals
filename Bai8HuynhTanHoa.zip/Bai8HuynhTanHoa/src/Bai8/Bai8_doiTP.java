/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_doiTP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);

        try {
            System.out.println("Nhap day nhi phan: ");
            int n = input.nextInt();
            System.out.println("Ket qua: " + doiSangThapPhan(n));
        } catch (InputMismatchException e) {
            System.out.println("Nhap khong dung dinh dang");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    static int doiSangThapPhan(int n) {

        if (n < 0) {
            throw new ArithmeticException("So can nhap phai la so duong");
        }
        String kQ = String.valueOf(n);
        for (int i = 0; i < kQ.length(); i++) {

            if (kQ.charAt(i) != '1' && kQ.charAt(i) != '0') {
                throw new ArithmeticException("Sai dinh dang");
            }
        }
        kQ = new StringBuffer(String.valueOf(n)).reverse().toString();

        int tong = 0, i;
        for (i = 0; i < kQ.length(); i++) {
            if (kQ.charAt(i) == '1') {
                tong += (int) Math.pow(2, i);
            }
        }
        return tong;
    }
    
}
