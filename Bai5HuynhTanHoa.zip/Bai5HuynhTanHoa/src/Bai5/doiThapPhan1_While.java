/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author huynh
 */
public class doiThapPhan1_While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap day so nhi phan: ");
        String n = input.nextLine();
        String reverse = new StringBuffer(n).reverse().toString();
        int thapPhan = 0;
        int temp;
        int i = 0;
        while (i<reverse.length()) {
            temp = reverse.charAt(i); // Lay vi tri 
            if (temp == '1') {
                int bienTam = 1;
                int j = 0;
                while (j < i) {
                    bienTam *= 2;
                    j++;
                }
                thapPhan += bienTam;
            }
            i++;
        }

//        for (int i = 0; i < reverse.length(); i++) {
//            temp = reverse.charAt(i); // Lay vi tri 
//            if (temp == '1') {
//                int bienTam = 1;
//                int j = 0;
//                while (j < i) {
//                    bienTam *= 2;
//                    j++;
//                }
//                thapPhan += bienTam;
//                for (int j = 0; j < i; j++) {
//                   
//                }
//                thapPhan+=bienTam;
//            }
//        }
        System.out.println("So Thap Phan: " + thapPhan);

    }

}
