/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author huynh
 */
public class tinhA1_While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        System.out.println("Nhap x:");
        int x = input.nextInt();
        //Tinh S
        double varA = 1, varB = 1, S = 0;
        int i = 0;
        while (i < n) {
            varA *= (x * x + x + 1);
            varB *= (x * x - x + 1);
            S = varA + varB;
            i++;
        }
//        for (int i = 0; i < n; i++) {
//            varA *= (x * x + x + 1);
//            varB *= (x * x - x + 1);
//            S = varA + varB;
//        }
        System.out.println("A= (x * x + x + 1) mu " + n + " +(x * x - x + 1) mu " + n + "=" + S);
    }

}
