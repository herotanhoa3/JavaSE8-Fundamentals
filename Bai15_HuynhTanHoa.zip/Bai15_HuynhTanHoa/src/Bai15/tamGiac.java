/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai15;

/**
 *
 * @author hocvien
 */
public class tamGiac {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public boolean laTamGiac(int a, int b, int c) {
        boolean kttamGiac = a + b > c && b + c > a && c + a > b;
        return kttamGiac;
    }
}
