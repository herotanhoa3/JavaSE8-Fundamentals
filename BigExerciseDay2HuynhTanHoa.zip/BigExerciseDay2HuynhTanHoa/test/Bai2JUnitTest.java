/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai2JUnitTest {

    public Bai2JUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //(double m3, int doiTuong, double soNguoi, int loai)
    @Test
    public void TestBai2_01() {
        double ex = 72220;
        double ac = Bai2.tinhTienNuoc(10, 1, 2, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_02() {
        double ex = 121900;
        double ac = Bai2.tinhTienNuoc(20, 1, 5, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_03() {
        double ex = 67045;
        double ac = Bai2.tinhTienNuoc(11, 1, 4, 0);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void TestBai2_04() {
        double ex = 925520;
        double ac = Bai2.tinhTienNuoc(80, 1, 4, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_05() {
        double ex = 441600;
        double ac = Bai2.tinhTienNuoc(40, 2, 0, 1);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_06() {
        double ex = 59225;
        double ac = Bai2.tinhTienNuoc(50, 2, 0, 2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_07() {
        double ex = 12600;
        double ac = Bai2.tinhTienNuoc(55, 1, 1, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_08() {
        double ex = 59225;
        double ac = Bai2.tinhTienNuoc(12, 1, 3, 0);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void TestBai2_09() {
        double ex = 441600;
        double ac = Bai2.tinhTienNuoc(5, 1, 1, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void TestBai2_10() {
        double ex = 59225;
        double ac = Bai2.tinhTienNuoc(12, 1, 2, 0);
        assertEquals(ex, ac, 0.01);
    }
}
