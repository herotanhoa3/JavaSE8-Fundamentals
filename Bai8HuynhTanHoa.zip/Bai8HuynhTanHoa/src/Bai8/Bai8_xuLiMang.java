/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author hoahuynh
 */
public class Bai8_xuLiMang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap n: ");
        try {
            String temp = input.readLine();
            int n = Integer.parseInt(temp);
            int[] arr = new int[n];
            Random random = new Random();
            for (int i = 0; i < n; i++) {
                arr[i] = random.nextInt(10);
            }
            System.out.println("Mang ngau nhien: " + xuatMang(arr));
            System.out.println("Tong cua mang la: " + tinhTong(arr));
        } catch (InputMismatchException e) {
            System.out.println("Nhap khong dung dinh dang");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } catch (NullPointerException e) {
            System.out.println(e.getMessage());
        }
    }
    public static String xuatMang(int[] arr) {
        if (arr == null) {
            System.out.println("null");
        }
        String kQ = "";
        for (int value : arr) {
            kQ += String.format(" %d ", value);
        }
        return kQ;
    }

    public static int tinhTong(int[] arr) {
        if (arr == null) {
            System.out.println("null");
        }
        int tong = 0;
        for (int value : arr) {
            tong += value;
        }
        return tong;
    }
    
}
