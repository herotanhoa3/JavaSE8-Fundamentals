/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_xuLyChuoiStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap chuoi sb: ");
        StringBuilder sb = new StringBuilder(input.nextLine());
        System.out.println("Nhap chuoi sb1: ");
        StringBuilder sb1 = new StringBuilder(input.nextLine());
        System.out.println("Nhap chuoi sb2: ");
        StringBuilder sb2 = new StringBuilder(input.nextLine());
        System.out.println("Nhap vi tri chen ");
        int viTri = input.nextInt();
        System.out.println("Nhập vị trí đầu: ");
        int viTriDau = input.nextInt();
        System.out.println("Nhập vị trí cuối: ");
        int viTriCuoi = input.nextInt();
        xuLyChuoi(sb, sb1, sb2, viTri, viTriDau, viTriCuoi);

    }

    static void xuLyChuoi(StringBuilder sb, StringBuilder sb1, StringBuilder sb2, int viTri, int viTriDau,int viTriCuoi) {
        System.out.println("Chieu dai chuoi sb: "+sb.length());
        System.out.println("Chuoi sb sau khi noi chuoi sb1: "+sb.append(sb1));
        System.out.println("Chuoi sb sau khi chen sb2 vao tai vi tri: "+sb.insert(viTri,sb2));
        System.out.println("Chuoi sb sau khi xoa noi dung tu vi tri dau den vi tri cuoi: "+sb.delete(viTriDau,viTriCuoi));
        System.out.println("Chuoi sb sau khi dao nguoc: "+sb.reverse());
        
    }
}
