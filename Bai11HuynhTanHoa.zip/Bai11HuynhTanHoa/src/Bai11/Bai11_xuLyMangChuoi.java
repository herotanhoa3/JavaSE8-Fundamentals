/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_xuLyMangChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        try {
            System.out.println("Nhap vao n: ");
            int n = input.nextInt();
            String[] mangTen = new String[n];
            xuLyMangChuoi(mangTen);
        } catch (Exception e) {
            System.err.println("Nhap n phai la so");
        }

    }

    static void xuLyMangChuoi(String[] mangTen) {
        Scanner input = new Scanner(System.in);
        boolean flag = false;

        for (int i = 0; i < mangTen.length; i++) {
            System.out.println("Nhap vao phan tu thu: " + (i + 1));
            mangTen[i] = input.nextLine();
        }
        for (int i = 0; i < mangTen.length; i++) {
            System.out.println("Mang vi tri " + (i + 1) + " la: " + mangTen[i]);
        }
        System.out.println("Nhập tên của một người: ");
        String ten = input.nextLine();
        for (int i = 0; i < mangTen.length; i++) {
            if (ten.equals(mangTen[i])) {
                System.out.println("Co ten " + ten + " trong mangTen tai vi tri " + (i + 1));
                break;
            } else {
                System.out.println("Khong co ten vua nhap trong mangTen");
            }
        }
        for (int i = 0; i < mangTen.length; i++) {
            for (int j = 0; j < mangTen[i].length(); j++) {
                char kiTu = mangTen[i].charAt(j);
                if (kiTu == 'n') {
                    System.out.println("Phan tu co chua ki tu 'n' " + mangTen[i]);
                    flag = true;
                    break;
                } else {
                    flag = false;
                }
            }
        }

        if (flag = false) {
            System.out.println("Khong co chua ki tu 'n'");
        }
        Arrays.sort(mangTen);
        System.out.print("Mang sau khi sap xep: ");
        for (int i = 0; i < mangTen.length; i++) {
            System.out.print(mangTen[i] + " ");
        }
    }
}
