/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class kiemTraNgayNhap {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap ngay: ");
        int ngay= input.nextInt();
        System.out.println("Nhap thang: ");
        int thang= input.nextInt();
        System.out.println("Nhap nam: ");
        int nam= input.nextInt();
        int soNgay=0;
        switch(thang)
        {
            case 1: case 3: case 5: case 7: case 8:
            case 10: case 12:
                        soNgay=31;
                        if(ngay<=31)
                        {
                            System.out.println("Ngay hop le");
                            if(ngay==31)
                            {
                                System.out.println("Ngay hom sau la ngay 1");
                                System.out.println("Ngay hom truoc la ngay 30");
                                if(thang==12 && ngay==31)
                                {
                                    System.out.println("Ngay hom sau la ngay: 1 nam "+(nam+1));
                                }
                            }
                            else
                                System.out.println("Ngay hom sau la ngay: "+(ngay+1));
                                System.out.println("Ngay hom truoc la ngay: "+(ngay-1));
                        }
                        else
                            System.out.println("Ngay khong hop le");
                        System.out.println("Thang nhap co 31 ngay");
                        //Nam moi
                        
                        break;
            case 4: case 6: case 9: case 11:
                        soNgay=30;
                        if(ngay<=30)
                        {
                            System.out.println("Ngay hop le");
                            if(ngay==30)
                            {
                                System.out.println("Ngay hom sau la ngay 1");
                                System.out.println("Ngay hom truoc la ngay 29");
                            }
                            else
                                System.out.println("Ngay hom sau la ngay: "+(ngay+1));
                                System.out.println("Ngay hom truoc la ngay: "+(ngay-1));
                        }
                        else
                            System.out.println("Ngay khong hop le");
                        System.out.println("Thang nhap co 30 ngay");
                        break;
            case 2:
                if(((nam% 4 == 0)   && 
                  !(nam % 100 == 0))||
                   (nam % 400 == 0))
                {
                    soNgay=29;
                    if(ngay<=29)
                        {
                            System.out.println("Ngay hop le");
                            if(ngay==29)
                            {
                                System.out.println("Ngay hom sau la ngay 1");
                                System.out.println("Ngay hom truoc la ngay 28");
                            }
                            else
                                System.out.println("Ngay hom sau la ngay: "+(ngay+1));
                                System.out.println("Ngay hom truoc la ngay: "+(ngay-1));
                        }
                        else
                            System.out.println("Ngay khong hop le");
                        System.out.println("Thang nhap co 29 ngay");
                    break;
                }
                else
                    soNgay=28;
                    if(ngay<=28)
                        {
                            System.out.println("Ngay hop le");
                            if(ngay==28)
                            {
                                System.out.println("Ngay hom sau la ngay 1");
                                System.out.println("Ngay hom truoc la ngay 27");
                            }
                            else
                                System.out.println("Ngay hom sau la ngay: "+(ngay+1));
                                System.out.println("Ngay hom truoc la ngay: "+(ngay-1));
                        }
                        else
                            System.out.println("Ngay khong hop le");
                        System.out.println("Thang nhap co 28 ngay");
                break;
            default:
                System.out.println("Khong co thang nay trong nam");
        }
        
    }
    
}
