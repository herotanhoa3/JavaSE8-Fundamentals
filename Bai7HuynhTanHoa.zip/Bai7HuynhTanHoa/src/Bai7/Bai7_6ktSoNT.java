/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_6ktSoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        ktSoNT(n);

    }

    public static void ktSoNT(int n) {
        boolean flag = false;
        if (n < 2) {
            System.out.println(n + " khong phai so NT");
        } else {
            for (int i = 2; i < n; i++) {
                if (n % i == 0) {
                    flag = true;
                }
            }
            if (flag == true) {
                System.out.println(n + " khong phai so NT");
            } else {
                System.out.println(n + " la so NT");
            }
        }

    }

}
