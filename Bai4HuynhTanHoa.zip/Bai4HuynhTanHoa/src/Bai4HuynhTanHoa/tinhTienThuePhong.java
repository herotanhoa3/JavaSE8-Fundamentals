/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class tinhTienThuePhong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap loai phong(tu 1 den 8): ");
        int loaiPhong= input.nextInt();
        System.out.println("Nhap so dem: ");
        int soDem= input.nextInt();
        switch(loaiPhong)
        {
            case 1:TinhTien(1260000,soDem);
                    break;
            case 2:TinhTien(1550000,soDem);
                    break;
            case 3:
            case 4:TinhTien(1830000,soDem);
                    break;
            case 5:
            case 6:TinhTien(2120000,soDem);
                    break;
            case 7:TinhTien(2540000,soDem);
                    break;
            case 8: TinhTien(4800000,soDem);
                    break;
        }
    }
    static void TinhTien(int soTien,int soDem)
        { 
            double thanhTien=0;
            if(soDem<=1)
                 {
                    thanhTien= soTien;
                 }
            else if(soDem<4)
                 {
                    thanhTien=  soTien*0.75*soDem;
                 }
            else
                    thanhTien= soTien*0.70*soDem;
            System.out.println("Thanh tien: "+thanhTien);
        }
    
}
