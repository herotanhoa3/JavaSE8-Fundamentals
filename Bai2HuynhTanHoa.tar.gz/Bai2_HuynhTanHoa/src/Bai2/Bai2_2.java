/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap so luong:");
        int soluong = input.nextInt();
        System.out.println("Nhap don gia:");
        int dongia = input.nextInt();
        int thanhtien= soluong*dongia;
        System.out.println("Thanh tien: " +thanhtien );
    }
    
}
