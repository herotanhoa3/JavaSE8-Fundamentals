/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        tinhTongNT(n);
    }

    public static void tinhTongNT(int n) {
        boolean dem = true;
        int tong=0;
        //tinh tong So NT
        for (int i = 2; i <= n; i++) {
            dem = true;
            for (int j = 2; j <= i / 2; j++) {
                if (i % j == 0) {
                    dem = false;
                    break;
                }
            }
            if (dem) {
            System.out.println(i);
            tong+=i;
            }
        }
        System.out.println("Tong cac so NT: "+tong);
    }
}
