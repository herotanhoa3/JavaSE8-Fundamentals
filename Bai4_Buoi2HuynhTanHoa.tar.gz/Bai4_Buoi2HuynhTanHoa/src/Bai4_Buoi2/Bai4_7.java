/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4_Buoi2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Tong thu nhap trong nam: ");
        int tongThuNhap= input.nextInt();
        System.out.println("So nguoi phu thuoc: ");
        int soNguoiPhuThuoc= input.nextInt();
        //Tinh 
        int bacThue1= 60000000, bacThue2=120000000, bacThue3=216000000,
            bacThue4=384000000, bacThue5=624000000, bacThue6=960000000;
        
        double laiSuat1=0.05,   laiSuat2=0.1,      laiSuat3=0.15,
               laiSuat4=0.2,   laiSuat5=0.25,      laiSuat6=0.3,    laiSuat7=0.35;
        
        double soTienGiamTru= 9000000*12+soNguoiPhuThuoc*3600000*12;
        double soTienChiuThue= tongThuNhap-soTienGiamTru;
        double soTienThue=0;
        
        if(tongThuNhap<=soTienGiamTru)
        {
            System.out.println("Khong phai dong thue");
        }
        else if( soTienChiuThue <= bacThue1)
        {
             soTienThue=soTienChiuThue*laiSuat1;
        }
        else if(soTienChiuThue> bacThue1 &&  soTienChiuThue <= bacThue2)
        {
             soTienThue=bacThue1*laiSuat1 +(soTienChiuThue-bacThue1)*laiSuat2;
        }
        else if(soTienChiuThue> bacThue2 &&  soTienChiuThue <= bacThue3)
        {
             soTienThue=bacThue1*laiSuat1 +bacThue1*laiSuat2 +(soTienChiuThue-bacThue2)*laiSuat3;
        }
        else if(soTienChiuThue> bacThue3 &&  soTienChiuThue <= bacThue4)
        {
             soTienThue=bacThue1*laiSuat1 + bacThue1*laiSuat2 +(bacThue3-bacThue2)*laiSuat3+
                    (soTienChiuThue-bacThue3)*laiSuat4;
        }
        else if(soTienChiuThue> bacThue4 &&  soTienChiuThue <= bacThue5)
        {
             soTienThue=bacThue1*laiSuat1 + bacThue1*laiSuat2 +(bacThue3-bacThue2)*laiSuat3+
                    (bacThue4-bacThue3)*laiSuat4 +(soTienChiuThue-bacThue4)*laiSuat5;
        }
        else if(soTienChiuThue> bacThue5 &&  soTienChiuThue <= bacThue6)
        {
             soTienThue=bacThue1*laiSuat1 + bacThue1*laiSuat2 +(bacThue3-bacThue2)*laiSuat3+
                    (bacThue4-bacThue3)*laiSuat4 +(bacThue5-bacThue4)*laiSuat5 
                    +(soTienChiuThue-bacThue5)*laiSuat6;
        }
        else 
        {
             soTienThue=bacThue1*laiSuat1 + bacThue1*laiSuat2 +(bacThue3-bacThue2)*laiSuat3+
                    (bacThue4-bacThue3)*laiSuat4 +(bacThue5-bacThue4)*laiSuat5 
                    +(bacThue6-bacThue5)*laiSuat6 + (soTienChiuThue-bacThue6)*laiSuat7;
        }
        System.out.println("So tien giam tru: "+ String.format("%.0f",soTienGiamTru));
        System.out.println("So tien chiu thue: "+ String.format("%.0f",soTienChiuThue));
        System.out.println("Tien thue phai nop la: "+soTienThue);
        
        
        
    }
    
}
