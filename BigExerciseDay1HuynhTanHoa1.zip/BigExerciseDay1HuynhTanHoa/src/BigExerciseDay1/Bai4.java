/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        int n = input.nextInt();
        String[] mangA = new String[n];
        nhapMang(n, mangA);
        int max = kiemTraChuoi(mangA);
        for (int i = 0; i < mangA.length; i++) {
            if (mangA[i].length() == max) {
                System.out.println("Vi tri cua phan tu dai nhat: " + i + " Gia tri: " + mangA[i]);
                break;
            }
        }
        nhapChuoi(mangA);
        System.out.println("Mang moi la");
        taoMang(mangA);
    }

    static void nhapMang(int n, String[] mangA) {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < mangA.length; i++) {
            System.out.println("Nhap phan tu thu " + i);
            mangA[i] = input.next();
        }
        for (int i = 0; i < mangA.length; i++) {
            System.out.println("Phan tu thu: " + i);
            System.out.println("Noi dung: " + mangA[i]);
            System.out.println("chieu dai: " + mangA[i].length());
            System.out.println();
        }
    }

    static int kiemTraChuoi(String[] mangA) {
        int daiNhat = 0;
        for (int i = 0; i < mangA.length; i++) {
            if (i == 0) {
                daiNhat = mangA[i].length();
            } else {
                daiNhat = Math.max(daiNhat, mangA[i].length());
            }
        }
        return daiNhat;
    }

    static void nhapChuoi(String[] mangA) {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap chuoi: ");
        String chuoi = input.nextLine();
        boolean flag = false;
        for (int i = 0; i < mangA.length; i++) {
            if (mangA[i].equals(chuoi)) {
                System.out.println("Co gia tri giong voi chuoi vua nhap vi tri: " + i);
                flag = true;
                break;
            } else {
                flag = false;
            }
        }
        if (flag == false) {
            System.out.println("Khong co gia tri giong voi chuoi vua nhap");
        }
    }

    static void taoMang(String[] mangA) {
        String[] mangSaoChep = new String[mangA.length];
        System.arraycopy(mangA, 0, mangSaoChep, 0, mangA.length);
        Arrays.sort(mangSaoChep);
        for (String string : mangSaoChep) {
            System.out.println(string);
        }
        
    }
}
