/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

/**
 *
 * @author hocvien
 */
public class Bai6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        inBangCuuChuong();
    }

    static void inBangCuuChuong() {
        int[][] bangCuuChuong = new int[10][10];
        for (int i = 1; i < bangCuuChuong.length; i++) {
            for (int j = 1; j < bangCuuChuong[i].length; j++) {
                bangCuuChuong[i][j] = i * j;
            }
        }
        System.out.println("Bang Cuu Chuong:");
        System.out.println("-------------------------------");
        for (int i = 1; i < bangCuuChuong.length; i++) {
            System.out.print(i + "|");
            for (int j = 1; j < bangCuuChuong[i].length; j++) {
                System.out.print(+bangCuuChuong[i][j] + " ");
            }
            System.out.println();
        }
    }
}
