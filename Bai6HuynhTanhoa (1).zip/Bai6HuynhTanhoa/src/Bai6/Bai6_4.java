/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int[] arr = new int[5];
        System.out.println("Nhap mang co 5 phan tu:");
        for (int i = 0; i < 5; i++) {
            arr[i] = input.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            System.out.println(arr[i] + ", ");
        }
        System.out.print("Cap chia het:");
        for (int i = 0; i < 5; i++) {
            for (int j = i + 1; j < 5; j++) {
                if (arr[i] % arr[j] == 0 || arr[j] % arr[i] == 0) {
                    System.out.print(" " + arr[i] + " & " + arr[j] + ", ");
                }
            }
        }
        System.out.println("");
        System.out.print("Cap gap 2 lan het:");
        for (int i = 0; i < 5; i++) {
            for (int j = i + 1; j < 5; j++) {
                if (arr[i] * 2 == arr[j] || arr[j] * 2 == arr[i]) {
                    System.out.print(" " + arr[i] + " & " + arr[j] + ", ");
                }
            }
        }
        System.out.println("");
        System.out.print("Cap tong 2 so =8 la :");
        for (int i = 0; i < 5; i++) {
            for (int j = i + 1; j < 5; j++) {
                if (arr[i] + arr[j] == 8 || arr[j] + arr[i] == 8) {
                    System.out.print(" " + arr[i] + " & " + arr[j] + ", ");
                }
            }
        }
        System.out.println("");

    }

}
