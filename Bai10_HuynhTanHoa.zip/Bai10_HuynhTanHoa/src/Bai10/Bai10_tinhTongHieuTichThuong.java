/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai10;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai10_tinhTongHieuTichThuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap x: ");
        double x = input.nextDouble();
        System.out.println("Nhap y: ");
        double y = input.nextDouble();
        System.out.println("Dap an phep Cong: "+ tinhToan.CONG.tinh(x, y));
        System.out.println("Dap an phep Tru: "+ tinhToan.TRU.tinh(x, y));
        System.out.println("Dap an phep Nhan: "+ tinhToan.NHAN.tinh(x, y));
        System.out.println("Dap an phep Chia: "+ tinhToan.CHIA.tinh(x, y));
    }

}

enum tinhToan {
    CONG,
    TRU,
    NHAN,
    CHIA;

    double tinh(double x, double y) {
        switch (this) {
            case CONG:
                return x + y;
            case TRU:
                return x - y;
            case NHAN:
                return x * y;
            case CHIA:
                return x / y;
            default: 
                throw new AssertionError("tinh khong duoc "+ this);
        }

}
}
