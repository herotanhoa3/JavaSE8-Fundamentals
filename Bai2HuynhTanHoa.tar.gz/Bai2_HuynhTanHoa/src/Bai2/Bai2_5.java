/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao Chu vi hinh chu nhat: ");
        double chuVi= input.nextInt();
        double chieuRong = chuVi/5;
        double tinhDientich= chieuRong*(1.5*chieuRong);
        System.out.println("Dien tich cua hinh chu nhat la: "+ String.format("%.2f", tinhDientich));
        
    }
    
}
