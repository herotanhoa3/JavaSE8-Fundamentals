/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_soSanhStringVaStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String s = "";
        StringBuilder sb = new StringBuilder();
        long thoiGianSBD = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            s = s.concat(i + " ");
        }
        long thoiGianSKT = System.currentTimeMillis();
        long thoiGianSBBD = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            sb = sb.append(i + " ");
        }
        long thoiGianSBKT = System.currentTimeMillis();
        System.out.println("Chieu dai cua chuoi s: " + s.length());
        System.out.println("Chieu dai cua chuoi sb: " + sb.length());
        System.out.println("Thoi gian thuc hien s: " + (thoiGianSKT - thoiGianSBD) + " milisecond");
        System.out.println("Thoi gian thuc hien sb: " + (thoiGianSBKT - thoiGianSBBD) + " milisecond");
        if ((thoiGianSKT - thoiGianSBD) > (thoiGianSBKT - thoiGianSBBD)) {
            System.out.println("Thoi gian s dai hon sb");
        } else {
            System.out.println("Thoi gian sb dai hon s");
        }
    }

}
