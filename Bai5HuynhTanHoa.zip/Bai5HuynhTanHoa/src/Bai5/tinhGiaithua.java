/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class tinhGiaithua {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.print("Nhap n:");
        int n = input.nextInt();
        int Giaithua = 1;
        int GiaithuaChang = 2;
        int GiaithuaLe = 1;
        //tinh giai thua
        for (int i = 1; i <= n; i++) {
            Giaithua *= i;
        }
        System.out.println(n + "!  = " + Giaithua);
        if (n % 2 == 0) {
            for (int j = 4; j <= n; j++) {
                if (j % 2 == 0) {
                GiaithuaChang *= j;
                }
            }
            System.out.println(n + "!  = " + GiaithuaChang);
        } else {
            for (int z = 3; z <= n; z++) {
                if (z % 2 != 0) {
                GiaithuaLe *= z;
                }
            }
            System.out.println(n + "!  =" + GiaithuaLe);
        }

    }

}
