/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class tinhCuocTaxi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input= new Scanner(System.in);
        System.out.println("Nhap vao loai xe (4 hoac 7): ");
        int loaiXe= input.nextInt();
        System.out.println("Nhap vao so km: ");
        int giaMD=11000;
        double soKm= input.nextDouble();
        if(loaiXe==4)
        {
            double thanhTien;
            if(soKm<=0.8)
            {
                thanhTien= giaMD;
            }
            else if(0.8<soKm && soKm<=30)
            {
                thanhTien=giaMD+ (soKm-0.8)*16500;
            }
            else
            {
                thanhTien= giaMD+ 29.2*16500 + (soKm-30)*12400;
            }
            System.out.println("Thanh tien: " +thanhTien);
        }
        if(loaiXe==7)
        {
            double thanhTien;
            if(soKm<=0.8)
            {
                thanhTien= giaMD;
            }
            else if(0.8<soKm && soKm<=30)
            {
                thanhTien= giaMD+ (soKm-0.8)*17000;
            }
            else
            {
                thanhTien= giaMD+ 29.2*17000 + (soKm-30)*14400;
            }
            System.out.println("Thanh tien: " +thanhTien);
        }
    }
    
}
