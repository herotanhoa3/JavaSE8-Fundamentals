/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class timMaxMin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap a: ");
        int a= input.nextInt();
        System.out.println("Nhap b: ");
        int b= input.nextInt();
        System.out.println("Nhap c: ");
        int c= input.nextInt();
        System.out.println("Nhap d: ");
        int d= input.nextInt();
        System.out.println("Gia tri a, b, c, d: " +a+ ","+b+ ","+c+ ","+d);
        if(a>b && a>c && a>d)
        {
            System.out.println("So lon nhat la: " +a);
        }
        else if(b>a && b>c && b>d)
        {
            System.out.println("So lon nhat la: " +b);
        }
        else if(c>a && c>b && c>d)
        {
            System.out.println("So lon nhat la: " +c);
        }
        else
           System.out.println("So lon nhat la: " +d); 
        
        //so be
        if(a<b && a<c && a<d)
        {
            System.out.println("So be nhat la: " +a);
        }
        else if(b<a && b<c && b<d)
        {
            System.out.println("So be nhat la: " +b);
        }
        else if(c<a && c<b && c<d)
        {
            System.out.println("So be nhat la: " +c);
        }
        else
           System.out.println("So be nhat la: " +d); 
        
    }
}
