/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_inBangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        try {
            System.out.println("In tu so: ");
            int tuSo = input.nextInt();
            System.out.println("Den so: ");
            int denSo = input.nextInt();
            inBangCuuChuong(tuSo, denSo);
        } catch (InputMismatchException e) {
            System.out.println("Nhap khong dung dinh dang");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } 
    }

    static void inBangCuuChuong(int tuSo, int denSo) {

        if (tuSo < 0) {
            throw new ArithmeticException("So can nhap phai la so duong");
        }
        if (denSo < tuSo) {
            throw new ArithmeticException("Sai thu tu");
        }
        String kq = "";
        int i, j;
        for (i = 1; i <= 9; i++) {
            for (j = tuSo; j <= denSo; j++) {
                kq += String.format("%d x %d = %d\t", j, i, (j * i));
            }
            System.out.println(kq);
            kq = "";
        }
    }
    
}
