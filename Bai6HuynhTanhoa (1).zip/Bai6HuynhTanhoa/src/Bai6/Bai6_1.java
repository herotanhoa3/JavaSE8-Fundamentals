/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai6_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap n:");
        String n = input.readLine();
        int m = Integer.parseInt(n);
        int arr[] = new int[m];
        int tong = 0;
        Random random = new Random();
        System.out.println("Mang ngau nhien");
        for (int i = 0; i < m; i++) {
            arr[i] = random.nextInt(10);
            System.out.print(arr[i] + " ");
            tong += arr[i];
        }
        System.out.print("\n");
        System.out.println("Tong = " + tong);
    }

}
