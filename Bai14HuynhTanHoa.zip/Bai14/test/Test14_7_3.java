/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import Bai14.bai14_7_3;

/**
 *
 * @author hocvien
 */
public class Test14_7_3 {

    public Test14_7_3() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test1() {
        int[][] mang = {{1, 2, 2}, {4, 2, 2}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 2;
        assertEquals(ac, ex);
    }

    @Test
    public void test2() {
        int[][] mang = {{1, 1, 1}, {4, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 1;
        assertEquals(ac, ex);
    }

    @Test
    public void test3() {
        int[][] mang = {{2, 2, 3}, {3, 2, 3}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 2;
        assertEquals(ac, ex);
    }

    @Test
    public void test4() {
        int[][] mang = {{6, 2, 6}, {4, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 6;
        assertEquals(ac, ex);
    }

    @Test
    public void test5() {
        int[][] mang = {{1, 2, 3}, {1, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 1;
        assertEquals(ac, ex);
    }

    @Test
    public void test6() {
        int[][] mang = {{1, 2, 2}, {4, 2, 2}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 4;
        assertEquals(ac, ex);
    }

    @Test
    public void test7() {
        int[][] mang = {{1, 1, 1}, {4, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 5;
        assertEquals(ac, ex);
    }

    @Test
    public void test8() {
        int[][] mang = {{1, 2, 3}, {3, 2, 3}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 1;
        assertEquals(ac, ex);
    }

    @Test
    public void test9() {
        int[][] mang = {{6, 2, 3}, {4, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 2;
        assertEquals(ac, ex);
    }

    @Test
    public void test10() {
        int[][] mang = {{1, 2, 3}, {4, 5, 6}};
        int ac = bai14_7_3.timSoXHNN(mang);
        int ex = 9;
        assertEquals(ac, ex);
    }
}
