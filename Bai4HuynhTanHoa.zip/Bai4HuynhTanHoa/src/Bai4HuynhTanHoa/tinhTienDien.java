/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4HuynhTanHoa;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class tinhTienDien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input= new Scanner(System.in);
        System.out.println("Nhap so kw tieu thu: ");
        int kw = input.nextInt();
        double thanhTien;
        if(0<kw && kw<=50)
        {
             thanhTien= kw*1388;
        }
        else if(50<kw && kw<=100)
        {
             thanhTien= 50*1388 +(kw-50)*1433;
        }
        else if(100<kw && kw<=200)
        {
             thanhTien= 50*1388 +50*1433 +(kw-100)*1660;
        }
        else if(200<kw && kw<=300)
        {
             thanhTien= 50*1388 +50*1433 +100*1660+ (kw-200)*2082;
        }
        else if(300<kw && kw<=400)
        {
             thanhTien= 50*1388 +50*1433 +100*1660+100*2082 +(kw-300)*2324;
        }
        else 
        {
             thanhTien= 50*1388 +50*1433 +100*1660+100*2082 +100*2324 +(kw-400)*2399;
        }
        System.out.println("Thanh tien: "+thanhTien);
    }
    
}
