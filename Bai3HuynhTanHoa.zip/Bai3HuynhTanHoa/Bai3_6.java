/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai3HuynhTanHoa;

/**
 *
 * @author hocvien
 */
public class Bai3_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x=10;
        int y=4;
        boolean equivalence=x==y;
        System.out.println("x == y is "+equivalence);
        
        boolean nonEquivalence=x!=y;
        System.out.println("x != y is "+nonEquivalence);
        
        boolean lessthan=x<y;
        System.out.println("x < y is "+lessthan);
        
        boolean greaterthan=x>y;
        System.out.println("x > y is "+greaterthan);
        
        boolean lessOrEqual=x<=y;
        System.out.println("x > y is "+lessOrEqual);
        
        boolean greaterOrEqual=x>=y;
        System.out.println("x > y is "+greaterOrEqual);
    }
    
}
