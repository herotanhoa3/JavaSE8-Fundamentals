/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int[] a = vongLap();
        System.out.println();
        System.out.println("Nhap x:");
        int x = input.nextInt();
        timX(x, a);
    }

    public static int[] vongLap() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        int[] a = new int[n];
        System.out.println("Nhap gia tri cho cac phan tu trong mang");
        for (int i = 0; i < n; i++) {
            a[i] = input.nextInt();
        }
        System.out.println("Mang da nhap:");
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
        return a;
    }

    public static void timX(int x, int[] a) {
        for (int i = 0; i < x; i++) {
            if (x == a[i]) {
                System.out.println(x + " Xuat hien trong mang tai vi tri: " + i);
                break;
            }
            else
                System.out.println("-1");
        }
    }
}
