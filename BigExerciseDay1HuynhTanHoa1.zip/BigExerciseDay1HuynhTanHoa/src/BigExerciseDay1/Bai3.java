/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String loaiGhe = "";
        int tongSoVe = 0;
        int soVeNguoiLon = 0;
        int soVeTreEm = 0;
        int soVeNguoiGia = 0;
        try {
            System.out.println("Nhap loai Ghe: ");
            loaiGhe = input.nextLine().toUpperCase();
            System.out.println("Nhap tong so Ve muon mua: ");
            tongSoVe = input.nextInt();
            System.out.println("Nhap so Ve nguoi lon: ");
            soVeNguoiLon = input.nextInt();
            System.out.println("Nhap tong so Ve tre em: ");
            soVeTreEm = input.nextInt();
            System.out.println("Nhap tong so Ve nguoi gia: ");
            soVeNguoiGia = input.nextInt();
        } catch (Exception e) {
            System.err.println("Nhap sai dinh dang");
            main(args);
            return;
        }
        if (tongSoVe < soVeNguoiLon + soVeTreEm + soVeNguoiGia) {
            System.err.println("Nhap sai so luong");
            main(args);
            return;
        }
        chonLoaiGhe(loaiGhe, tongSoVe);
        tinhTienVe(tongSoVe, soVeNguoiLon, soVeTreEm, soVeNguoiGia, chonLoaiGhe(loaiGhe, tongSoVe));
    }

    public static double chonLoaiGhe(String loaiGhe, int tongSoVe) {
        double tienVe = 0;
        switch (loaiGhe) {
            case "A2T":
                tienVe = 129000;
                break;
            case "A2TL":
                tienVe = 128000;
                break;
            case "ANLT1":
                tienVe = 249000;
                break;
            case "ANLT2":
                tienVe = 218000;
                break;
            case "ANT1":
                tienVe = 202000;
                break;
            case "ANT2":
                tienVe = 172000;
                break;
            case "BNLT1":
                tienVe = 214000;
                break;
            case "BNLT2":
                tienVe = 189000;
                break;
            case "BNLT3":
                tienVe = 163000;
                break;
            case "BNT1":
                tienVe = 193000;
                break;
            case "BNT2":
                tienVe = 168000;
                break;
            case "BNT3":
                tienVe = 146000;
                break;
            case "GP":
                tienVe = 79000;
                break;
            case "NC":
                tienVe = 99000;
                break;
            case "NCL":
                tienVe = 116000;
                break;
            case "NM":
                tienVe = 129000;
                break;
            case "NML":
                tienVe = 155000;
                break;
            case "NML4V":
                tienVe = 171000;
                break;
            default:
                System.err.print("Nhap sai loai ghe");
                break;
        }
        return tienVe;
    }

    public static double tinhTienVe(int tongSoVe, int soVeNguoiLon, int soVeTreEm, int soVeNguoiGia, double tienVe) {
        double tienVeNguoiLon = tienVe * soVeNguoiLon;
        double tienVeTreEm = tienVe * soVeTreEm * 0.5;
        double tienVeNguoiGia = tienVe * soVeNguoiGia * 0.75;
        double tongTienVe = tienVeNguoiLon + tienVeTreEm + tienVeNguoiGia;
        System.out.println("Tong so ve: " + tongSoVe + " ve");
        System.out.println("Ve nguoi lon: " + soVeNguoiLon + " ve. Thanh tien: " + tienVeNguoiLon + " vnd");
        System.out.println("Ve tre em: " + soVeTreEm + " ve. Thanh tien: " + tienVeTreEm + " vnd");
        System.out.println("Ve nguoi gia: " + soVeNguoiGia + " ve. Thanh tien: " + tienVeNguoiGia + " vnd");
        System.out.println("Tong so tien: " + tongTienVe + " vnd");
        return tongTienVe;
    }
}
