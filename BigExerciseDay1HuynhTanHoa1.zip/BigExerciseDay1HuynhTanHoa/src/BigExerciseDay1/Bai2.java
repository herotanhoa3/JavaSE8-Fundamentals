/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2 {

    public static Scanner input = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        int n = input.nextInt();
        int[][] maTranVuong = new int[n][n];
        inMaTran(n, maTranVuong);
        timMin(maTranVuong);
        timMax(maTranVuong);
        System.out.println("Nhap x: ");
        int x = input.nextInt();
        soNguyenX(x, n, maTranVuong);
        timSoAmLonNho(n, maTranVuong);
        demPhanTu(n, maTranVuong);
        demSoAm(n, maTranVuong);
    }

    static void inMaTran(int n, int[][] maTranVuong) {
//        Scanner input = new Scanner(System.in);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.println("Vi tri: " + i + " " + j);
                maTranVuong[i][j] = input.nextInt();
            }
        }
        System.out.println("Ma tran vuong la: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(maTranVuong[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static int timMin(int[][] maTranVuong) {
        int min = 0;
        //Tim gia tri nho nhat
        for (int i = 0; i < maTranVuong.length; i++) {
            min = maTranVuong[i][0];
            for (int j = 0; j < maTranVuong.length; j++) {
                if (i == 0 && j == 0) {
                    min = maTranVuong[i][j];
                }
                if (maTranVuong[i][j] < min) {
                    min = maTranVuong[i][j];
                }
            }
            System.out.println("Gia tri nho nhat hang " + i + " la: " + min);
        }
        return min;
    }

    public static int timMax(int[][] maTranVuong) {
        int max = 0;
        for (int i = 0; i < maTranVuong.length; i++) {
            max = maTranVuong[i][0];
            for (int j = 0; j < maTranVuong.length; j++) {
                if (i == 0 && j == 0) {
                    max = maTranVuong[i][j];
                }
                if (maTranVuong[i][j] > max) {
                    max = maTranVuong[i][j];
                }
            }
            System.out.println("Gia tri lon nhat hang " + i + " la: " + max);
        }
        return max;
    }

//    static void timMaxMin(int[][] maTranVuong) {
//
//        //Tim gia tri lon 
//    }

    static void soNguyenX(int x, int n, int[][] maTranVuong) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j || i + j == maTranVuong.length - 1) {
                    maTranVuong[i][j] = x;
                }
            }
        }
        System.out.println("Ma tran vuong X la: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(maTranVuong[i][j] + " ");
            }
            System.out.println();
        }
    }

    static void timSoAmLonNho(int n, int[][] maTranVuong) {
        int soAmLonNhat = 0;
        int soDuongNhoNhat = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (maTranVuong[i][j] < 0) {
                    if (soAmLonNhat == 0) {
                        soAmLonNhat = maTranVuong[i][j];
                    } else {
                        soAmLonNhat = Math.max(soAmLonNhat, maTranVuong[i][j]);
                    }
                }
                if (maTranVuong[i][j] >= 0) {
                    if (soDuongNhoNhat == 0) {
                        soDuongNhoNhat = maTranVuong[i][j];
                    } else {
                        soDuongNhoNhat = Math.min(soDuongNhoNhat, maTranVuong[i][j]);
                    }
                }
            }
        }
        System.out.println("So am lon nhat: " + soAmLonNhat);
        System.out.println("So duong nho nhat: " + soDuongNhoNhat);
    }

    static void demPhanTu(int n, int[][] maTranVuong) {
        int dem = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i <= j) {
                    if (maTranVuong[i][j] > 0) {
                        dem++;
                    }
                }
            }
        }
        System.out.println("So phan tu duong co gia tri nam o tren tam giac phia tren duong cheo la: " + dem);
    }

    static void demSoAm(int n, int[][] maTranVuong) {
        int dem = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (maTranVuong[i][j] < 0) {
                    if (maTranVuong[i][j] % 2 == 0 && maTranVuong[i][j] % 3 == 0) {
                        dem++;
                    }
                }
            }
        }
        System.out.println("Tong so am chia het cho 2 va 3 la: " + dem);
    }
}
