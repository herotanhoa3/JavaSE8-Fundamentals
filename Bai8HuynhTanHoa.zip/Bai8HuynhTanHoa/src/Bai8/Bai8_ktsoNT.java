/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_ktsoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);

        System.out.println("Nhap n: ");
        try {
            int soNguyen = input.nextInt();
            kiemTraSoNT(soNguyen);
        } catch (InputMismatchException e) {
            System.out.println("Ban can nhap vao so");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }

    }

    static void kiemTraSoNT(int soNguyenTo) {

        if (soNguyenTo < 0) {
            throw new ArithmeticException("So can kiem tra khong duoc am");
        }
        String chuoi = "Day la so nguyen to";
        if (soNguyenTo < 2) {
            chuoi = "Khong phai la so nguyen to";
        } else if (soNguyenTo > 2) {
            int i;
            int temp = (int) Math.sqrt(soNguyenTo);
            for (i = 2; i <= temp; i++) {
                if (soNguyenTo % i == 0) {
                    chuoi = "Khong phai la so nguyen to";
                }

            }
        }
        System.out.println(chuoi);
    }
    
}
