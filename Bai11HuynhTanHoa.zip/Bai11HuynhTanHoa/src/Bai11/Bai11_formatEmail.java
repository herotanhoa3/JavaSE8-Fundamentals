/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai11_formatEmail {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        formatEmail();
    }

    static void formatEmail() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao Email: ");
        String check = input.nextLine();
        Pattern p = Pattern.compile("[_a-zA-Z0-9-+]+([.][a-zA-Z0-9_-]+)*@([A-Za-z0-9_])+(\\.[a-zA-Z.]{2,})");
        Matcher m1 = p.matcher(check);
        boolean r1 = m1.matches();
        if (r1 == true) {
            System.out.println("Email hop le: " + r1);
        } else {
            System.out.println("Email khong hop le: " + r1);
        }
    }
}
