/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_6tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        tinhGTBT(n);
    }
    public static void tinhGTBT(int n){
        int A = 0, B = 0, C = 1, D = 1;
        for (int i = 1; i <= n; i++) {
            if (i % 2 != 0) {
                A += i;
            }
            if (i % 2 == 0) {
                B += i;
            }
            C *= i;
            if (i % 3 == 0) {
                D *= i;
            }
        }
        System.out.println("Ket qua A = "+A);
        System.out.println("Ket qua B = "+B);
        System.out.println("Ket qua C = "+C);
        System.out.println("Ket qua D = "+D);
    }
}
