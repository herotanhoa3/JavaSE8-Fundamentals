/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input= new Scanner(System.in);
        System.out.println("Nhap vao Ten ngoai te: ");
        String ngoaiTe= input.nextLine();
        System.out.println("Ty gia: ");
        double tyGia= input.nextDouble();
        System.out.println("So ngoai te ");
        double soNgoaiTe= input.nextDouble();
        double thanhTien= tyGia*soNgoaiTe;
        System.out.println("Ban dang doi tu:" +ngoaiTe+" sang VND");
        System.out.println("Thanh tien: " +String.format("%.1f", thanhTien));
    }
    
}
