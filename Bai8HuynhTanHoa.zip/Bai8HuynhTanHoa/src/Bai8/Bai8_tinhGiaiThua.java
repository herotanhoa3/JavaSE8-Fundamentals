/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_tinhGiaiThua {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        try {
            int n = input.nextInt();
            tinhGT1(n);
            tinhGT2(n);
        } catch (InputMismatchException e) {
            System.out.println("Nhap khong dung dinh dang");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }
    static void tinhGT1(int n) {
        if (n < 0) {
            throw new ArithmeticException(" Khong duoc nhap so am");
        }
        String kQ = n + "! = ";
        int i, tich = 1;
        if (n == 0) {
            kQ = "0! = 1";
        } else {
            for (i = 1; i <= n; i++) {
                if (i == 1) {
                    kQ += "1";
                } else {
                    kQ += " x " + i;
                }
                tich *= i;
            }
        }
        System.out.println(kQ + " = " + tich);
    }
    static void tinhGT2(int n) {
        if (n < 0) {
            throw new ArithmeticException(" Khong duoc nhap so am");
        }
        String kQ = n + "!! = ";
        int i, tich = 1;
        if (n == 0) {
            kQ = "0!! = 1 ";
        } else if (n % 2 == 0) {
            for (i = 1; i <= n; i++) {
                if (i % 2 == 0) {
                    kQ += i + " x ";
                    tich *= i;
                }
            }
        } else {
            for (i = 1; i <= n; i++) {
                if (i % 2 != 0) {
                    kQ += i + " x ";
                    tich *= i;
                }
            }
        }
        kQ = kQ.substring(0, kQ.length() - 2);
        System.out.println(kQ + " = " + tich);
    }
    
}
