/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_doiNP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        try {
            int n = input.nextInt();
            System.out.println(doiNP(n));
        } catch (InputMismatchException e) {
            System.out.println("Sai dinh dang");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    static String doiNP(int n) {
        if (n < 0) {
            throw new ArithmeticException("So can chuyen phai la so duong");
        }
        String kQ = "";
        while (n != 0) {
            String temp = String.valueOf(n % 2);
            kQ += temp;
            n = n / 2;
        }
        kQ = new StringBuffer(kQ).reverse().toString();
        return kQ;
    }

}
