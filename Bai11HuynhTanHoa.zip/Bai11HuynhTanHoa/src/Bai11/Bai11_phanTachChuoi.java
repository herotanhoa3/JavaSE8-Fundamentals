/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai11_phanTachChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            phanTachChuoi();
        } catch (Exception e) {
            System.err.println("Sai dinh dang");
        }
    }

    static void phanTachChuoi() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap chuoi can phan tach");
        String chuoi = input.nextLine();
        System.out.println("Nhap ki tu can phan tach");
        String kiTu = input.nextLine();
        StringTokenizer st = new StringTokenizer(chuoi, kiTu);
        System.out.println("Cac token: ");
        while (st.hasMoreTokens()) {
            System.out.println(""+st.nextToken());
        }
    }
}
