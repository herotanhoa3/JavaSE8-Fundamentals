/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class formatUsername {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        try {
            formatUsername();
//        } catch (Exception e) {
//            System.err.println("Sai dinh dang");
//        }
    }

    static void formatUsername() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhập vào username: ");
        String check = input.nextLine();
        Pattern p = Pattern.compile("[a-z0-9_-]{6,20}");
        Matcher m1 = p.matcher(check);
        boolean r1 = m1.matches();
        if (r1 == true) {
           System.out.println("Tên hợp lệ: "+r1);
        } else {
             System.out.println("Ten không hợp lệ: " +r1);
        }
    }
}
