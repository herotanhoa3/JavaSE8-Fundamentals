
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import sun.text.normalizer.UTF16;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        doanChu();
    }
    static void doanChu() throws IOException {
        String[] mang = {"program", "developer", "testing", "coder", "algorithm", "bug", "console", "user", "system", "application"};
        boolean flag = true;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Co 10 tu tieng Anh");
        System.out.println("Ban chon tu thu may? (1-10)");
        int viTri = 0;
        while (flag) {
            try {
                viTri = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                flag = true;
                System.out.println("Vui Long nhap so!! ");
                continue;
            }
            if (viTri < 0 || viTri > mang.length) {
                System.out.println("Nhap sai yeu cau nhap lai !!");
                continue;
            }
            flag = false;
        }
        String chuoi = mang[viTri];
        System.out.print("Ban vua chon tu so "+viTri+". Tu co " + chuoi.length() + " ki tu: ");
        char[] kiTu = new char[chuoi.length()];
        for (int i = 0; i < kiTu.length; i++) {
            kiTu[i] = chuoi.charAt(i);
        }
        char[] hienThi = new char[chuoi.length()];
        for (int i = 0; i < kiTu.length; i++) {
            hienThi[i] = '*';
            System.out.print(hienThi[i]);
        }
        System.out.println();
        String tu = "";
        boolean thang = false;
        flag = true;
        int soLanChoi=1;
        while (!thang) {
            while (flag) {
                System.out.println("Lan "+soLanChoi+". Ban doan ki tu:  ");
//                System.out.println("moi ban doan 1 tu");
                tu = input.readLine();
                if (tu.length() > 1) {
                    System.out.println("Nhap qua ki tu cho phep ");
                    continue;
                }
                int dem = 0;
                for (int i = 0; i < kiTu.length; i++) {
                    if (kiTu[i] == tu.charAt(0)) {
                        hienThi[i] = kiTu[i];
                        dem++;
                    }
                }
                if (dem > 0) {
                    System.out.print("Chuc mung ban!! co " + dem + " tu " + tu.charAt(0)+": ");
                } else {
                    System.out.println("Rat tiec!! Doan sai moi doan lai");
                }
                for (int i = 0; i < hienThi.length; i++) {
                    System.out.print(hienThi[i]);
                }
                System.out.println();
                int diem=0;
                for (int i = 0; i < hienThi.length; i++) {
                    if(hienThi[i]==kiTu[i]){
                        diem++;
                    }
                }
                if(diem==kiTu.length)
                {
                    flag = false;
                    thang=true;
                }
                soLanChoi++;
            }
        }
        if(thang){
            System.out.println("Chuc mung ban da chien thang !!");
        }
    }
}
