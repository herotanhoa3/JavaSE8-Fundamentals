/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai11_phanTachHoTen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            phanTachHoTen();
        } catch (Exception e) {
            System.err.println("Sai dinh dang");
        }
    }

    static void phanTachHoTen() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhập họ tên đầy đủ: ");
        String hoTen = input.nextLine();
        StringTokenizer st = new StringTokenizer(hoTen);
        String ho = st.nextToken();
        String tenDem = "";
        while (st.countTokens() > 1) {
            tenDem = st.nextToken();
        }
        String ten = st.nextToken();
        System.out.println("Ho: " + ho);
        System.out.println("Ten Dem: " + tenDem);
        System.out.println("Ten: " + ten);
    }

}
