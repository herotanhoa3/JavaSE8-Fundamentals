/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        System.out.println("Nhap x:");
        double x = input.nextDouble();
        System.out.println("A= (x * x + x + 1) mu " + n + " +(x * x - x + 1) mu " + n + "=" + tinhA(n, x));
    }

    public static double tinhA(int n, double x) {
        double varA = 1, varB = 1, A = 0;
        for (int i = 0; i < n; i++) {
            varA *= (x * x + x + 1);
            varB *= (x * x - x + 1);
            A = varA + varB;
        }
        return A;
    }

}
