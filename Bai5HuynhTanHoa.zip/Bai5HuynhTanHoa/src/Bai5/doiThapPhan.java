/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author huynh
 */
public class doiThapPhan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap day so nhi phan: ");
        String n = input.nextLine();
        String reverse = new StringBuffer(n).reverse().toString();
        int thapPhan = 0;
        int temp;

        for (int i = 0; i < reverse.length(); i++) {
            temp = reverse.charAt(i); // Lay vi tri 
            if (temp == '1') {
                int bienTam = 1;
                for (int j = 0; j < i; j++) {
                   bienTam*=2;
                }
                thapPhan+=bienTam;
            }
        }
        System.out.println("So Thap Phan: "+thapPhan);

    }

}
