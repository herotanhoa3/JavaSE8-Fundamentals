/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_tinhSoNguyen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        try {
            int n = input.nextInt();
            System.out.println("Tong cac so chan: " + tinhTongChan(n));
            System.out.println("Tong cac so le: " + tinhTongLe(n));
            System.out.println("Tich la: " + tinhTich(n));
            System.out.println("Tich cac so chia het cho 3: " + tinhTongTich(n));
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc bo trong");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }
    static int tinhTongChan(int n) {
        if (n < 0) {
            throw new ArithmeticException("So khong am");
        }
        int tinhTong = 0, i;
        for (i = 1; i <= n; i++) {
            if (i % 2 == 0) {
                tinhTong += i;
            }
        }
        return tinhTong;
    }

    static int tinhTongLe(int n) {
        if (n < 0) {
            throw new ArithmeticException("So khong am");
        }
        int tinhTong = 0, i;
        for (i = 1; i <= n; i++) {
            if (i % 2 != 0) {
                tinhTong += i;
            }
        }
        return tinhTong;
    }
    static int tinhTich(int n) {
        if (n < 0) {
            throw new ArithmeticException("So khong am");
        }
        int tinhTich = 1, i;
        if (n == 0) {
            tinhTich = 0;
        }
        for (i = 1; i <= n; i++) {
            tinhTich *= i;
        }
        return tinhTich;
    }
    static int tinhTongTich(int n) {
        if (n < 0) {
            throw new ArithmeticException("So khong am");
        }
        int tinhTich = 1, i;
        if (n == 0) {
            tinhTich = 0;
        }
        for (i = 1; i <= n; i++) {
            if (i % 3 == 0) {
                tinhTich *= i;
            }
        }
        return tinhTich;
    }
    
}
