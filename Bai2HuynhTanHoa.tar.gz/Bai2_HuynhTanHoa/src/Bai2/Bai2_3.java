/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap ban kinh");
        float banKinh= input.nextFloat();
        float PI=3.14f;
        float chuVi ;
        float dienTich=0;
        chuVi= 2*banKinh*PI;
        dienTich=banKinh*banKinh*PI;
        System.out.println("Chu vi la: " +String.format("%.2f", chuVi));
        System.out.println("Dien tich la: " +String.format("%.2f", dienTich));
        
        
    }
    
}
