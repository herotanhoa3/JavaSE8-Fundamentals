/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao dien tich cua hinh tron: ");
        float dienTich= input.nextFloat();
        float PI=3.14f;
        double tinhBanKinh =0;
        tinhBanKinh= Math.sqrt(dienTich/PI);
        System.out.println("Ban kinh cua hinh tron la: "+ String.format("%.2f", tinhBanKinh));
    }
    
}
