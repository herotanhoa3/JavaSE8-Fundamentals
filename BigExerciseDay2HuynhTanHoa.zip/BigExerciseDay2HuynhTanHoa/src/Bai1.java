
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai1 {

    static Scanner input = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        nhapLieu();
    }

    public static void nhapLieu() {
        int vung = 0;
        int vung2 = 0;
        System.out.println("Nhap trong luong buu pham: ");
        int trongLuong = input.nextInt();
        System.out.println("Chon hinh thuc gui (1) (2) (3):");
        int hinhThuc = input.nextInt();
        System.out.println("Chon EMS: ");
        System.out.println("Noi tinh (1)/ Lien tinh (2)");
        int eMS = input.nextInt();
        if (eMS == 2) {
            System.out.println("Chon vung: ");
            System.out.println("vung (1) / vung (2) / vung (3) ");
            vung = input.nextInt();
            if (vung == 2) {
                System.out.println("Chon Da Nang di Ha Noi, HCM (1) / Ha Noi di HCM (2) ");
                vung2 = input.nextInt();
            }
        }
        System.out.println(tinhCuocHinhThuc1(hinhThuc, trongLuong, eMS, vung, vung2));

    }

    public static double tinhCuocHinhThuc1(int hinhThuc, int trongLuong, int eMS, int vung, int vung2) {
        double giaCuoc = 0;
        int temp = 0;
        int temp1 = 0;
        int soDu = 0;
        int nac = 500;
        int trongLuong1 = 50, trongLuong2 = 100, trongLuong3 = 250, trongLuong4 = 500,
                trongLuong5 = 1000, trongLuong6 = 1500, trongLuong7 = 2000;

        switch (hinhThuc) {
            case 1:
                if (eMS == 1) {
                    if (trongLuong <= trongLuong1) {
                        giaCuoc = 8000;
                    } else if (trongLuong > trongLuong1 && trongLuong <= trongLuong2) {
                        giaCuoc = 8000;
                    } else if (trongLuong > trongLuong2 && trongLuong <= trongLuong3) {
                        giaCuoc = 10000;
                    } else if (trongLuong > trongLuong3 && trongLuong <= trongLuong4) {
                        giaCuoc = 12500;
                    } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                        giaCuoc = 15000;
                    } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                        giaCuoc = 18000;
                    } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                        giaCuoc = 21000;
                    } else if (trongLuong > trongLuong7) {
                        soDu = trongLuong - trongLuong7;
                        temp = soDu / nac;
                        temp1 = soDu % nac;
                        if (temp1 > 0) {
                            temp++;
                        }
                        giaCuoc = 21000 + temp * 1600;
                    }
                } else if (eMS == 2) {
                    if (vung == 1) {
                        if (trongLuong <= trongLuong1) {
                            giaCuoc = 8500;
                        } else if (trongLuong > trongLuong1 && trongLuong <= trongLuong2) {
                            giaCuoc = 12500;
                        } else if (trongLuong > trongLuong2 && trongLuong <= trongLuong3) {
                            giaCuoc = 16500;
                        } else if (trongLuong > trongLuong3 && trongLuong <= trongLuong4) {
                            giaCuoc = 23500;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 33000;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 40000;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 48500;
                        } else if (trongLuong > trongLuong7) {
                            soDu = trongLuong - trongLuong7;
                            temp = soDu / nac;
                            temp1 = soDu % nac;
                            if (temp1 > 0) {
                                temp++;
                            }
                            giaCuoc = 48500 + temp * 3800;
                        }
                    } else if (vung == 2) {
                        if (vung2 == 1) {
                            if (trongLuong <= trongLuong1) {
                                giaCuoc = 9500;
                            } else if (trongLuong > trongLuong1 && trongLuong <= trongLuong2) {
                                giaCuoc = 13500;
                            } else if (trongLuong > trongLuong2 && trongLuong <= trongLuong3) {
                                giaCuoc = 20000;
                            } else if (trongLuong > trongLuong3 && trongLuong <= trongLuong4) {
                                giaCuoc = 26500;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 38500;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 49500;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 59500;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 59500 + temp * 8500;
                            }
                        }
                        if (vung2 == 2) {
                            if (trongLuong <= trongLuong1) {
                                giaCuoc = 9500;
                            } else if (trongLuong > trongLuong1 && trongLuong <= trongLuong2) {
                                giaCuoc = 13500;
                            } else if (trongLuong > trongLuong2 && trongLuong <= trongLuong3) {
                                giaCuoc = 21500;
                            } else if (trongLuong > trongLuong3 && trongLuong <= trongLuong4) {
                                giaCuoc = 28000;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 40500;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 52500;
                            } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                                giaCuoc = 63500;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 63500 + temp * 8500;
                            }
                        }
                    } else if (vung == 3) {
                        if (trongLuong <= trongLuong1) {
                            giaCuoc = 10000;
                        } else if (trongLuong > trongLuong1 && trongLuong <= trongLuong2) {
                            giaCuoc = 14000;
                        } else if (trongLuong > trongLuong2 && trongLuong <= trongLuong3) {
                            giaCuoc = 22500;
                        } else if (trongLuong > trongLuong3 && trongLuong <= trongLuong4) {
                            giaCuoc = 29500;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 43500;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 55500;
                        } else if (trongLuong > trongLuong4 && trongLuong <= trongLuong5) {
                            giaCuoc = 67500;
                        } else if (trongLuong > trongLuong7) {
                            soDu = trongLuong - trongLuong7;
                            temp = soDu / nac;
                            temp1 = soDu % nac;
                            if (temp1 > 0) {
                                temp++;
                            }
                            giaCuoc = 67500 + temp * 9500;
                        }
                    }
                }
                break;
            case 2:
                if (eMS == 1) {
                    if (trongLuong <= trongLuong7) {
                        giaCuoc = 50000;
                    } else if (trongLuong > trongLuong7) {
                        soDu = trongLuong - trongLuong7;
                        temp = soDu / nac;
                        temp1 = soDu % nac;
                        if (temp1 > 0) {
                            temp++;
                        }
                        giaCuoc = 50000 + temp * 5000;
                    }
                } else if (eMS == 2) {
                    if (vung == 1) {
                        if (trongLuong <= trongLuong7) {
                            giaCuoc = 70000;
                        } else if (trongLuong > trongLuong7) {
                            soDu = trongLuong - trongLuong7;
                            temp = soDu / nac;
                            temp1 = soDu % nac;
                            if (temp1 > 0) {
                                temp++;
                            }
                            giaCuoc = 70000 + temp * 7000;
                        }
                    } else if (vung == 2) {
                        if (vung2 == 1) {
                            if (trongLuong <= trongLuong7) {
                                giaCuoc = 110000;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 110000 + temp * 12000;
                            }
                        } else if (vung2 == 2) {
                            if (trongLuong <= trongLuong7) {
                                giaCuoc = 130000;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 130000 + temp * 20000;
                            }
                        }
                    }
                }
                break;
            case 3:
                if (eMS == 1) {
                    if (trongLuong <= trongLuong7) {
                        giaCuoc = 50000;
                    } else if (trongLuong > trongLuong7) {
                        soDu = trongLuong - trongLuong7;
                        temp = soDu / nac;
                        temp1 = soDu % nac;
                        if (temp1 > 0) {
                            temp++;
                        }
                        giaCuoc = 50000 + temp * 5000;
                    }
                } else if (eMS == 2) {
                    if (vung == 1) {
                        if (trongLuong <= trongLuong7) {
                            giaCuoc = 70000;
                        } else if (trongLuong > trongLuong7) {
                            soDu = trongLuong - trongLuong7;
                            temp = soDu / nac;
                            temp1 = soDu % nac;
                            if (temp1 > 0) {
                                temp++;
                            }
                            giaCuoc = 70000 + temp * 7000;
                        }
                    } else if (vung == 2) {
                        if (vung2 == 1) {
                            if (trongLuong <= trongLuong7) {
                                giaCuoc = 85000;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 85000 + temp * 10000;
                            }
                        } else if (vung2 == 2) {
                            if (trongLuong <= trongLuong7) {
                                giaCuoc = 100000;
                            } else if (trongLuong > trongLuong7) {
                                soDu = trongLuong - trongLuong7;
                                temp = soDu / nac;
                                temp1 = soDu % nac;
                                if (temp1 > 0) {
                                    temp++;
                                }
                                giaCuoc = 100000 + temp * 12000;
                            }
                        }
                    } else if (vung == 3) {
                        if (trongLuong <= trongLuong7) {
                            giaCuoc = 110000;
                        } else if (trongLuong > trongLuong7) {
                            soDu = trongLuong - trongLuong7;
                            temp = soDu / nac;
                            temp1 = soDu % nac;
                            if (temp1 > 0) {
                                temp++;
                            }
                            giaCuoc = 110000 + temp * 15000;
                        }
                    }
                }
                break;
            default:
                System.err.println("Nhap sai hinh thuc!!");
                break;
        }
        return giaCuoc;
    }
}
