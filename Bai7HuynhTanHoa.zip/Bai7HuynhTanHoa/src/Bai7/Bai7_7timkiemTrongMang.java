/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_7timkiemTrongMang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        timkiemTrongMang(n);
    }

    public static void timkiemTrongMang(int n) {
        Scanner input = new Scanner(System.in);
        int[] arr = new int[n];
        int max = 0;
        System.out.println("Nhap gia tri cho cac phan tu trong mang");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }
        System.out.println("Nhap x:");
        int x = input.nextInt();
        System.out.println("Mang da nhap:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            if (x == arr[i]) {
                System.out.println(x + " Xuat hien trong mang tai vi tri: " + i);
            }
        }
        System.out.println("Cac so lon hon no la: ");
        for (int i = 0; i < n; i++) {
            if (arr[i] > x) {
                System.out.print(arr[i] + " ");
            }

        }
    }
}
