/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai4_Buoi2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Chon nhiet do 'C' va do 'F' ");
        String nhietCF= input.nextLine();
        System.out.println("Nhap nhiet do: ");
        double nhietDo= input.nextDouble();
        if(nhietCF.equals("C") || nhietCF.equals("c"))
        {
            double chuyenNhietDo= (9/5f*nhietDo)+32; 
            
            
            System.out.println(nhietDo+" do C "+"="+String.format("%.0f", chuyenNhietDo)+" do F");
        }
        else if(nhietCF.equals("F") || nhietCF.equals("f"))
        {
             double chuyenNhietDo= (5*(nhietDo-32))/9;
            System.out.println(nhietDo+" do F "+"="+String.format("%.0f", chuyenNhietDo)+" do C");
        }
        else
        {
            System.out.println("Nhap ki tu sai, yeu cau chon lai!!!");
        }
    }
    
}
