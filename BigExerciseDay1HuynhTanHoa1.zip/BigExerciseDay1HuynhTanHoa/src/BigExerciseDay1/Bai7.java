/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String giaTri = "";
        try {
            System.out.println("Chon loai doi");
            System.out.println("(1)thap phan sang thap luc phan");
            System.out.println("(2)thap luc phan sang thap phan");
            int n = input.nextInt();
            System.out.println("Nhap gia tri can doi: ");
            giaTri = input.next();
            luaChonPT(n, giaTri);
        } catch (Exception e) {
            System.err.println("Sai dinh dang nhap vao");
        }

    }

    public static String doiThapLucPhan(int d) {
        String chuoi = "0123456789ABCDEF";
        if (d <= 0) {
            return "0";
        }
        int heSo = 16;
        String hex = "";
        while (d > 0) {
            int kiTu = d % heSo;
            hex = chuoi.charAt(kiTu) + hex;
            d = d / heSo;
        }
        return hex;
    }

    public static int doiThapPhan(String s) {
        String chuoi = "0123456789ABCDEF";
        s = s.toUpperCase();
        int giaTri = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int d = chuoi.indexOf(c);
            giaTri = 16 * giaTri + d;
        }
        return giaTri;
    }

    public static void luaChonPT(int n, String giaTri) {
        switch (n) {
            case 1:
                String chuoi = "";
                int temp = Integer.parseInt(giaTri);
                chuoi = doiThapLucPhan(temp);
                System.out.println("Gia tri sau khi doi sang Thap luc phan: " + chuoi);
                break;
            case 2:
                int soThapPhan = 0;
                soThapPhan = doiThapPhan(giaTri);
                System.out.println("Gia tri sau khi doi san Thap phan: " + soThapPhan);
                break;
            default:
                System.err.println("Ban da chon sai truong hop!!");
                break;
        }
    }
}
