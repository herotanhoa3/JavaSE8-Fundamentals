/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai4JUnitTest {
    
    public Bai4JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void TestBai4_1() {
        int[] mang = {2,4,1,5};
        int n= 4;
        double ex = 3;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_2() {
        int[] mang = {7,4,9,5};
        int n= 4;
        double ex = 6.25;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_3() {
        int[] mang = {3,4,10,7};
        int n= 4;
        double ex = 6;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_4() {
        int[] mang = {9,4,3,9};
        int n= 4;
        double ex = 6.25;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_5() {
        int[] mang = {8,8,8,8};
        int n= 4;
        double ex = 8;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_6() {
        int[] mang = {3,4,3,9};
        int n= 4;
        double ex = 6.25;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_7() {
        int[] mang = {8,2,8,8};
        int n= 4;
        double ex = 8;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_8() {
        int[] mang = {1,4,1,9};
        int n= 4;
        double ex = 6.25;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_9() {
        int[] mang = {5,5,2,2};
        int n= 4;
        double ex = 8;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    @Test
    public void TestBai4_10() {
        int[] mang = {1,1,2,2};
        int n= 4;
        double ex = 8;
        double ac = Bai4.tinhDiemTB(mang, n);
        assertEquals(ex, ac,0.01);
    }
    
}
