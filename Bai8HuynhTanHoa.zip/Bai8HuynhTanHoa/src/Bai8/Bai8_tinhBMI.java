/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_tinhBMI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Scanner input = new Scanner(System.in);
            System.out.println("Nhap chieu cao:");
            double chieuCao = input.nextDouble();
            System.out.println("Nhap can nang:");
            double canNang = input.nextDouble();
            double BMI = tinhBMI(chieuCao, canNang);
            System.out.println("BMI = " + BMI + " - Ket luan: " + danhGiaBMI(BMI));
        } catch (ArithmeticException | IllegalArgumentException e) {

            System.out.println("Loi: " + e.getMessage());
        }
    }

    static double tinhBMI(double chieuCao, double canNang) {
        return canNang / (chieuCao * chieuCao);
    }

    static String danhGiaBMI(double BMI) {
        if (BMI < 18.5) {
            return "Ban gay";
        } else if (BMI < 24.99) {
            return "Ban binh thuong";
        } else {
            return "Ban thua  can";
        }
    }
    
}
