
import java.util.Random;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class Bai3 {

    public static Scanner input = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        xuatMang();

    }

    public static void xuatMang() {
        Random random = new Random();
        int[][] mang = {{random.nextInt(10), random.nextInt(10), random.nextInt(10)},
        {random.nextInt(10), random.nextInt(10), random.nextInt(10)},
        {random.nextInt(10), random.nextInt(10), random.nextInt(10)}};
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                System.out.print(mang[i][j] + " ");
            }
            System.out.println();
        }
        sapXepCot(mang);
        System.out.println("Tong phan tu dong chan, cot le: " + tinhTongPT(mang));
        System.out.println("Thay -1 cho cac so nguyen to: ");
        soNguyenTo(mang);
        tinhTongCotDong(mang);
        System.out.println("So chinh phuong o vi tri: ");
        inChinhPhuong(mang);
    }

    public static void sapXepCot(int[][] mang) {
        System.out.println("Nhap vao cot: ");
        int temp = 0;
        int n = input.nextInt();
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                if (n == j) {
                    for (int z = i + 1; z < mang.length; z++) {
                        if (mang[i][j] > mang[z][j]) {
                            temp = mang[i][j];
                            mang[i][j] = mang[z][j];
                            mang[z][j] = temp;
                        }
                    }
                }
            }
        }
        System.out.println("Mang sau khi sap xep cot: ");
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                System.out.print(mang[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static int tinhTongPT(int[][] mang) {
        int tinhTong = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i % 2 == 0) {
                for (int j = 0; j < mang.length; j++) {
                    if (j % 2 != 0) {
                        tinhTong += mang[i][j];
                    }
                }
            }
        }
        return tinhTong;
    }

    public static void soNguyenTo(int[][] mang) {
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                if (kiemTraNT(mang[i][j])) {
                    mang[i][j] = -1;
                }
            }
        }
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang.length; j++) {
                System.out.print(mang[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static boolean kiemTraNT(int bien) {
        if (bien < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(bien); i++) {
            if (bien % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void tinhTongCotDong(int[][] mang) {
        int[] tinhTong = new int[4];
        for (int i = 0; i < mang.length; i++) {
            tinhTong[0] += mang[i][0];
            tinhTong[1] += mang[i][mang[0].length - 1];
        }
        for (int i = 0; i < mang[0].length; i++) {
            tinhTong[2] += mang[0][i];
            tinhTong[3] += mang[mang.length - 1][i];
        }
        System.out.println("Tong phan tu dong dau tien: " + tinhTong[2]);
        System.out.println("Tong phan tu dong cuoi cung: " + tinhTong[3]);
        System.out.println("Tong phan tu cot dau tien: " + tinhTong[0]);
        System.out.println("Tong phan tu cot cuoi cung: " + tinhTong[1]);

    }

    public static boolean ktSoChinhPhuong(int n) {
        if (n == (int) Math.sqrt(n) * (int) Math.sqrt(n)) {
            return true;
        }
        return false;
    }

    public static void inChinhPhuong(int[][] mang) {
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (ktSoChinhPhuong(mang[i][j]) == true) {
                    System.out.println("Dong " + i + " Cot " + j);
                    System.out.println("" + mang[i][j]);
                }
            }
        }
    }
}
