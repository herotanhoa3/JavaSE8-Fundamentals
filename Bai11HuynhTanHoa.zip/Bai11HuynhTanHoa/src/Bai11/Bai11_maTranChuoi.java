/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_maTranChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hinh A)");
        hinhA();
        System.out.println();
        System.out.println("Hinh B)");
        hinhB();
        System.out.println();
        System.out.println("Hinh C)");
        hinhC();
        System.out.println();
        System.out.println("Hinh D)");
        hinhD();
        System.out.println();
        System.out.println("Hinh E)");
        hinhE();
        System.out.println();
        System.out.println("Hinh F)");
        hinhF();
        System.out.println();
        System.out.println("Hinh G)");
        hinhG();
        System.out.println();
        System.out.println("Hinh H)");
        hinhH();
        System.out.println();
        System.out.println("Hinh I)");
        hinhI();
    }

    static void hinhA() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i >= j) {
                    System.out.print("# ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhB() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i <= j) {
                    System.out.print("# ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhC() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i <= j) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhD() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i + j < 7) {
                    System.out.print("  ");
                } else {
                    System.out.print("# ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhE() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || j == 6 || i == 0 || j == 0) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhF() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == j || i == 0 || i == 6) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhG() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i + j == 6 || i == 0 || i == 6) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhH() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i + j == 6 || i == j || i == 0 || i == 6) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }

    static void hinhI() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i + j == 6 || i == j || j == 0 || j == 6 || i == 0 || i == 6) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }
}
