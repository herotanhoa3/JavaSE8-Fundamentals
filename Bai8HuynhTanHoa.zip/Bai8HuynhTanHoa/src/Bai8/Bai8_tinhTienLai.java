/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_tinhTienLai {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        System.out.println("Lai suat 1 thang:");
        try {
            double laiSuat = input.nextDouble();
            System.out.println("So tien gui:");
            int tienGui = input.nextInt();
            System.out.println("So thang:");
            int soThang = input.nextInt();

            double tienLai = tinhLai(laiSuat, tienGui, soThang);
            System.out.println(String.format("Tien Lai: %.2f", tienLai));
            System.out.println(String.format("TOng von lai la %.2f", tinhTongTien(tienLai, tienGui)));
        } catch (InputMismatchException e) {
            System.out.println("Nhap vao khong dung");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    public static double tinhLai(double laiSuat, int tienGui, int soThang) {
        if (laiSuat < 0 || tienGui < 0 || soThang < 0) {
            throw new ArithmeticException("Lai suat tien gui la so duong");
        }
        double tienLai = 0;
        tienLai = (tienGui * soThang) * (laiSuat / 12 / 100);
        return tienLai;
    }

    public static double tinhTongTien(double tienLai, int tienGui) {

        if (tienLai < 0 || tienGui < 0) {
            throw new ArithmeticException("Tien lai va gui lon hon khong");
        }
        double tongTien = 0;
        tongTien = tienGui + tienLai;
        return tongTien;
    }
    
}
