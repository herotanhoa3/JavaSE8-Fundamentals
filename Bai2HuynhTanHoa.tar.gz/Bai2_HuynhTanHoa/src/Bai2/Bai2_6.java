/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai2_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap vao lai suat: ");
        double laiSuat = input.nextDouble();
        System.err.println("Nhap vao so tien gui: ");
        double soTiengui= input.nextDouble();
        System.out.println("Nhap vao so thang gui: ");
        double soThanggui= input.nextDouble();
        double tinhTienLai= (soTiengui*soThanggui)*(laiSuat/100/12);
        double tongSoTien= soTiengui+tinhTienLai;
        System.out.println("Tien lai: " +String.format("%.1f", tinhTienLai));
        System.out.println("Tong so tien: " +String.format("%.1f", tongSoTien));
        
    }
    
}
