/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Tu so:");
        int n = input.nextInt();
        System.out.println("Den so:");
        int m = input.nextInt();
        //tinh Bang Cuu chuong
        for (int i = n; i <= m; i++) {
            for (int j = 1; j < 10; j++) {
                int Tich=i*j;
                System.out.println(i+ " x "+j+" = "+Tich);
            }
            System.out.println("\n");
            
        }
    }

}
