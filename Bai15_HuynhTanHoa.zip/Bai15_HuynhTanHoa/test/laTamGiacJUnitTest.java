/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai15.tamGiac;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class laTamGiacJUnitTest {

    tamGiac tamgiac = new tamGiac();

    public laTamGiacJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTamGiac1() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(1, 2, 4);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac2() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(2, 3, 4);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac3() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(3, 1, 5);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac4() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(4, 5, 6);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac5() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(10, 5, 20);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac6() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(1, 1, 1);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac7() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(2, 1, 4);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac8() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(5, 10, 8);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac9() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(6, 3, 10);
        assertTrue(ac);
    }
    @Test
    public void ktTamGiac10() {
        boolean ex = true;
        boolean ac = tamgiac.laTamGiac(2, 4, 5);
        assertTrue(ac);
    }
}
