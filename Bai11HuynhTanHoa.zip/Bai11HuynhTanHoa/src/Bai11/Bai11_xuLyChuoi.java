/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_xuLyChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap chuoi s1: ");
        String s1 = input.nextLine();
        System.out.println("Nhap chuoi s2: ");
        String s2 = input.nextLine();
        System.out.println("Nhap chuoi s3: ");
        String s3 = input.nextLine();
        System.out.println("Nhap vi tri v: ");
        int v = input.nextInt();
        System.out.println("Nhap vi tri v: ");
        xuLyChuoi(s1, s2, s3, v);

    }

    static void xuLyChuoi(String s1, String s2, String s3, int v) {
        System.out.println("Chieu dai chuoi s1 la: "+ s1.length());
        System.out.println("Chieu dai chuoi s2 la: "+ s2.length());
        System.out.println("Chieu dai chuoi s3 la: "+ s3.length());  
        //So sanh
        System.out.println("Ket qua so s1 & s2: " +s1.compareTo(s2));
        System.out.println("Vị trí xuất hiện đầu tiên của chuỗi s3 trong s1: " +s1.indexOf(s3));
        System.out.println("Chuoi s4: "+s1.substring(v));
    }

}
