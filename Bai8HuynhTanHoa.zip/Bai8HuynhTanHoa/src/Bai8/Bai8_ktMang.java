/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hoahuynh
 */
public class Bai8_ktMang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner input = new Scanner(System.in);

        try {
            System.out.println("Nhap chieu dai mang: ");
            int n = input.nextInt();

            System.out.println("Nhap gia tri mang: ");
            int[] arr = new int[n];
            System.out.println("");

            for (int i = 0; i < n; i++) {
                System.out.println("Tu so " + (i + 1));
                arr[i] = input.nextInt();
            }

            System.out.println("Nhap gia tri can kiem tra: ");
            int m = input.nextInt();

            System.out.println("Mang la: " + xuatMang(arr));
            System.out.println(kiemTra(m, arr));
            System.out.println(kiemTraLonHon(m, arr));
            if (kiemTraLonHon(m, arr).equals(m + " khong lon hon cac phan tu trong mang")) {
                System.out.println(timSoLonHon(m, arr));
            }
        } catch (InputMismatchException e) {
            System.out.println("Nhap khong dung dinh dang");
        } catch (NumberFormatException e) {
            System.out.println("Khong duoc de trong");
        } catch (NullPointerException e) {
            System.out.println(e.getMessage());
        }
    }

    static String xuatMang(int[] arr) {

        String kQ = "";
        for (int value : arr) {
            kQ += String.format(" %d ", value);
        }

        return kQ;
    }

    private static String kiemTra(int m, int[] arr) {

        if (arr == null) {
            System.out.println(" null");
        }
        String kQ = "Phan tu khong xuat hien trong mang";
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == m) {
                kQ = String.format("%d xuat hien trong mang vi tri %d", m, i + 1);
                break;
            }

        }
        return kQ;
    }

    static String kiemTraLonHon(int m, int[] arr) {

        if (arr == null) {
            System.out.println(" null");
        }
        String kQ = m + " lon hon tat ca phan tu trong mang";
        for (int value : arr) {
            if (value > m) {
                kQ = m + " khong lon hon tat ca cac phan tu trong mang";
            }
        }
        return kQ;
    }

    static String timSoLonHon(int m, int[] arr) {

        if (arr == null) {
            System.out.println(" null");
        }
        String kQ = "";
        for (int value : arr) {
            if (value > m) {
                kQ += value + " ";
            }
        }
        kQ = "Tat ca cac so lon hon " + m + ": " + kQ;
        return kQ;
    }
    
}
