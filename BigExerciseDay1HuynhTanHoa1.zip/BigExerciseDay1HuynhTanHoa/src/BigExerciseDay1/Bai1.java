/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tinhCuocMobile();
    }

    public static void tinhCuocMobile() {
        Scanner input = new Scanner(System.in);
        String ten = "";
        int dungLuong = 0;
        try {
            System.out.println("Nhap ten goi cuoc: ");
            ten = input.nextLine().toUpperCase();
            System.out.println("Nhap dung luong da su dung(KB): ");
            dungLuong = input.nextInt();
        } catch (Exception e) {
            System.err.println("Nhap sai dinh dang dung luong");
            return;
        }
        tinhCuoc(ten, dungLuong);
    }
    public static double tinhCuoc(String ten, int dungLuong) {
        double tongCuoc = 0;
        double gioihanM10 = 50 * 1024;
        double cuocM10 = 10000;
        double gioihan25 = 150 * 1024;
        double cuocM25 = 25000;
        double gioihan50 = 500 * 1024;
        double cuocM50 = 50000;
        double gioihan120 = 1.5 * 1024 * 1024;
        double cuocM120 = 120000;
        double cuocMax = 70000;
        double cuocMax100 = 100000;
        double cuocMax200 = 200000;
        double cuocMaxS = 50000;

        switch (ten) {
            case "M0":
                tongCuoc = dungLuong * 1.5;
                break;
            case "M10":
                if (dungLuong <= gioihanM10) {
                    tongCuoc = cuocM10;
                } else {
                    tongCuoc = cuocM10 + (dungLuong - gioihanM10) * 0.5;
                }
                break;
            case "M25":
                if (dungLuong <= gioihan25) {
                    tongCuoc = cuocM25;
                } else {
                    tongCuoc = cuocM25 + (dungLuong - gioihan25) * 0.5;
                }
                break;
            case "M50":
                if (dungLuong <= gioihan50) {
                    tongCuoc = cuocM50;
                } else {
                    tongCuoc = cuocM50 + (dungLuong - gioihan50) * 0.5;
                }
                break;
            case "M120":
                if (dungLuong <= gioihan120) {
                    tongCuoc = cuocM120;
                } else {
                    tongCuoc = cuocM120 + (dungLuong - gioihan120) * 0.5;
                }
                break;
            case "MAX":
                tongCuoc = cuocMax;
                break;
            case "MAX100":
                tongCuoc = cuocMax100;
                break;
            case "MAX200":
                tongCuoc = cuocMax200;
                break;
            case "MAXS":
                tongCuoc = cuocMaxS;
                break;
            default:
                System.err.println("Nhap sai ten goi cuoc");
                break;
        }
        System.out.println("Cuoc nguoi dung phai tra la: " + tongCuoc);
        return tongCuoc;
    }
}
