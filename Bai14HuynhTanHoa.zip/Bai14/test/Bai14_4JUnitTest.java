/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai14.Bai14_4;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai14_4JUnitTest {
    
    public Bai14_4JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void Bai14_4_TinhNam_01() {
        String ex = "Nham Than";
        String ac = Bai14_4.tinhNamAmLich(1992);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_02() {
        String ex = "Canh Thin";
        String ac = Bai14_4.tinhNamAmLich(2000);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_03() {
        String ex = "Ky Mao";
        String ac = Bai14_4.tinhNamAmLich(1999);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_04() {
        String ex = "Tan Mui";
        String ac = Bai14_4.tinhNamAmLich(2111);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_05() {
        String ex = "Canh Than";
        String ac = Bai14_4.tinhNamAmLich(1800);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_06() {
        String ex = "Ky Dan";
        String ac = Bai14_4.tinhNamAmLich(1789);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_07() {
        String ex = "Tan Suu";
        String ac = Bai14_4.tinhNamAmLich(2011);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_08() {
        String ex = "Quy Mao";
        String ac = Bai14_4.tinhNamAmLich(1553);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_09() {
        String ex = "Ky Than";
        String ac = Bai14_4.tinhNamAmLich(1789);
        assertEquals(ex ,ac);
    }
    @Test
    public void Bai14_4_TinhNam_10() {
        String ex = "Binh Dau";
        String ac = Bai14_4.tinhNamAmLich(2016);
        assertEquals(ex ,ac);
    }
}
