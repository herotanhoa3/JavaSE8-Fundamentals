/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai13;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import sun.java2d.pipe.SpanShapeRenderer;

/**
 *
 * @author hocvien
 */
public class Bai13_inNgayThanNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        inNgayThangNam();

    }

    static void inNgayThangNam() {
        SimpleDateFormat ngayDinhDang = new SimpleDateFormat("dd/MM/yyyy");
        Date ngay = new Date();
        System.out.println("Hom nay la ngay: " + ngayDinhDang.format(ngay));

        Calendar calendar = Calendar.getInstance();
        System.out.println("Hom nay la thu: " + calendar.get(calendar.DAY_OF_WEEK));
        System.out.println("Hom nay la tuan: " + calendar.get(calendar.WEEK_OF_YEAR));

        calendar.add(Calendar.WEEK_OF_YEAR, 1);
        System.out.println("Tuan toi la tuan: " + ngayDinhDang.format(calendar.getTime()));
    }

}
