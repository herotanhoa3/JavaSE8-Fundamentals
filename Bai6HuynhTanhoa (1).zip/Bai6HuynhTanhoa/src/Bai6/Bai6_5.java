/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n:");
        int n = input.nextInt();
        System.out.println("Nhap m:");
        int m = input.nextInt();
        int countOdd = 0, countEven = 0, valueEven = 0, valueOdd = 0;
        int max = 0, min = 0;
        int[][] arr = new int[n][m];
        int[] arr1 = new int[n * m];
        boolean flag = true;
        int dem = 0;
        //xuat mang
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.println("Vi tri: " + i + " " + j);
                arr[i][j] = input.nextInt();
                arr1[dem] = arr[i][j];
                dem++;
            }
        }
        System.out.print("\n");
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
                if (arr[i][j] % 2 == 0) {
                    countEven++;
                    valueEven += arr[i][j];

                } else {
                    countOdd++;
                    valueOdd += arr[i][j];
                }
                if (i == 0 && j == 0) {
                    max = min = arr[i][j];
                }
                max = Math.max(max, arr[i][j]);
                min = Math.min(min, arr[i][j]);
            }
            System.out.print("\n");
        }
        double averageEven;
        if (countEven == 0) {
            averageEven = 0;
        } else {
            averageEven = valueEven / countEven;
        }
        double averageOdd;
        if (countOdd == 0) {
            averageOdd = 0;
        } else {
            averageOdd = valueEven / countOdd;
        }

        System.out.println("Tong so chan: " + countEven);
        System.out.println("Tong so le: " + countOdd);
        System.out.println("Gia tri trung binh tong so chan: " + averageEven);
        System.out.println("Gia tri trung binh tong so le: " + averageOdd);
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] < 0) {
                    flag = false;
                }
                if (max == arr[i][j]) {
                    System.out.println("Phan tu lon nhat la: " + arr[i][j]);
                    System.out.println("Phan tu lon nhat o vi tri " + i + " " + j);
                }
            }
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (min == arr[i][j]) {
                    System.out.println("Phan tu nho nhat la: " + arr[i][j]);
                    System.out.println("Phan tu nho nhat o vi tri " + i + " " + j);
                }
            }
        }
        if (flag == false) {
            System.out.println("ma tran co phan tu am");
        } else {
            System.out.println("ma tran co khong co phan tu am");
        }
        int solanmax = 1, giamax = 0;
        int f = 0, fn = 1;
        for (int i = 0; i < arr1.length; i++) {
            System.out.print(arr1[i] + " ");
        }
        for (int i = 0; i < arr1.length; i++) {
            for (int j = i + 1; j < arr1.length - 1; j++) {
                if (arr1[i] == arr1[j]) {
                    fn++;
                    f = arr1[i];
                    if (fn > solanmax) {
                        solanmax = fn;
                        giamax = f;
                    }
                }
            }
            fn = 1;
            f = 0;
        }
        System.out.println(" Phan tu xuat hien nhieu nhat: " + giamax);
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] == giamax) {
                     System.out.println("Vi tri : "+i+" "+j);
                }
            }
        }
    }

}
