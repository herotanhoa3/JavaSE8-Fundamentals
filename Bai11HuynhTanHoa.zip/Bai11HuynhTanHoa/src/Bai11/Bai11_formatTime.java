/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai11_formatTime {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        formatTime();
    }

    static void formatTime() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nhập vào giờ: ");
        String check = input.nextLine();
        Pattern p = Pattern.compile("([0-1]?[0-9]|2[0-3]):[0-5][0-9]");
        Matcher m1 = p.matcher(check);
        boolean r1 = m1.matches();
        if (r1 == true) {
           System.out.println("Giờ hợp lệ: "+r1);
        } else {
             System.out.println("Giờ không hợp lệ: " +r1);
        }
       
    }
}
