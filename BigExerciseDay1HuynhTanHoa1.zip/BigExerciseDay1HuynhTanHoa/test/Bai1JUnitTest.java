/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import BigExerciseDay1.Bai1;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai1JUnitTest {

    public Bai1JUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testBai1_01() {
        double ex = 10000;
        double ac = Bai1.tinhCuoc("M10", 40000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_02() {
        double ex = 25000;
        double ac = Bai1.tinhCuoc("M25", 11100);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_03() {
        double ex = 144000;
        double ac = Bai1.tinhCuoc("M50", 700000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_04() {
        double ex = 4333568;
        double ac = Bai1.tinhCuoc("M120", 10000000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_05() {
        double ex = 70000;
        double ac = Bai1.tinhCuoc("MAX", 40000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_06() {
        double ex = 50000;
        double ac = Bai1.tinhCuoc("MAXS", 99999);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_07() {
        double ex = 200000;
        double ac = Bai1.tinhCuoc("MAX200", 77777);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_08() {
        double ex = 120000;
        double ac = Bai1.tinhCuoc("MAX100", 80000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_09() {
        double ex = 13000;
        double ac = Bai1.tinhCuoc("M0", 10000);
        assertEquals(ex, ac, 0.01);
    }
    @Test
    public void testBai1_10() {
        double ex = 40000;
        double ac = Bai1.tinhCuoc("M0", 40000);
        assertEquals(ex, ac, 0.01);
    }
}
