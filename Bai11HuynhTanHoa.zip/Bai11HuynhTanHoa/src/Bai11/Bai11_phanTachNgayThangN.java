/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai11_phanTachNgayThangN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        try {
            System.out.println("Nhap vao chuoi ngay thang nam dd-MM-yyyy");
            String chuoi = input.nextLine();
            StringTokenizer token = new StringTokenizer(chuoi, "-");
            String ngay = token.nextToken();
            String thang = token.nextToken();
            String nam = token.nextToken();
            System.out.println("Ngay: " + ngay);
            System.out.println("Thang: " + thang);
            System.out.println("Nam: " + nam);
        } catch (Exception e) {
            System.err.println("Sai dinh dang");
        }

    }

}
