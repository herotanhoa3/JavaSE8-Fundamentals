/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Bai15.phuongTrinh;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class phuongTrinhJUnitTest {
    phuongTrinh pt = new phuongTrinh();
    
    public phuongTrinhJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    boolean ktNghiem(double[] nghiemPT) {
        boolean flag;
        if (nghiemPT[2] == 1 || nghiemPT[2] == 2) {
            flag = false;
        } else {
            flag = true;
        }
        return flag;
    }
    void ktKetQua(double[] mang, double ex) {
        
        if (ktNghiem(mang)) {
            if (mang[1] == 0) {
                System.out.println("1");
                assertEquals(ex, mang[0], 0.1);

            } else {
                System.out.println("2");
                if (ex == mang[0]) {
                    assertEquals(ex, mang[0], 0.1);

                } else {
                    assertEquals(ex, mang[1], 0.1);
                }
            }
        }
    }

    @Test
    public void ktPhuongTrinh1() {
        System.out.println("bai ktPhuongTrinh 1");
        double[] mang = pt.giaiPhuongTrinhBac2(-1, 2, -4);
        double ex = 2.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh2() {
        System.out.println("bai ktPhuongTrinh 2");
        double[] mang = pt.giaiPhuongTrinhBac2(3, 4, 1);
        double ex = 3.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh3() {
        System.out.println("bai ktPhuongTrinh 3");
        double[] mang = pt.giaiPhuongTrinhBac2(1, 2, -7);
        double ex = -3.828;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh4() {
        System.out.println("bai ktPhuongTrinh 4");
        double[] mang = pt.giaiPhuongTrinhBac2(3, -7, 2);
        double ex = 1.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh5() {
        System.out.println("bai ktPhuongTrinh 5");
        double[] mang = pt.giaiPhuongTrinhBac2(5, -3, -1);
        double ex = -0.838;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh6() {
        System.out.println("bai ktPhuongTrinh 6");
        double[] mang = pt.giaiPhuongTrinhBac2(2, 11, 8);
        double ex = 1.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh7() {
        System.out.println("bai ktPhuongTrinh 7");
        double[] mang = pt.giaiPhuongTrinhBac2(4, -11, 8);
        double ex = 1.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh8() {
        System.out.println("bai ktPhuongTrinh 8");
        double[] mang = pt.giaiPhuongTrinhBac2(4, 1, 5);
        double ex = 1.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh9() {
        System.out.println("bai ktPhuongTrinh 9");
        double[] mang = pt.giaiPhuongTrinhBac2(2, -8, 16);
        double ex = 4.0;
        ktKetQua(mang, ex);
    }
    @Test
    public void ktPhuongTrinh10() {
        System.out.println("bai ktPhuongTrinh 10");
        double[] mang = pt.giaiPhuongTrinhBac2(2, -3, -4);
        double ex = -0.637;
        ktKetQua(mang, ex);
    }
}
