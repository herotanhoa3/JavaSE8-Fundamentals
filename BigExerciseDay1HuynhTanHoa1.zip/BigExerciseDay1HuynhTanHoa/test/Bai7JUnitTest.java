/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import BigExerciseDay1.Bai7;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai7JUnitTest {
    
    public Bai7JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testBai3_01() {
        String ex = "A";
        String ac = Bai7.doiThapLucPhan(10);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_02() {
        String ex = "C8";
        String ac = Bai7.doiThapLucPhan(200);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_03() {
        String ex = "3E8";
        String ac = Bai7.doiThapLucPhan(1000);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_04() {
        String ex = "2BC";
        String ac = Bai7.doiThapLucPhan(700);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_05() {
        String ex = "14D";
        String ac = Bai7.doiThapLucPhan(333);
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_06() {
        int ex = 242;
        int ac = Bai7.doiThapPhan("578");
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_07() {
        int ex = 512;
        int ac = Bai7.doiThapPhan("200");
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_08() {
        int ex = 2048;
        int ac = Bai7.doiThapPhan("800");
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_09() {
        int ex = 1000;
        int ac = Bai7.doiThapPhan("500");
        assertEquals(ex, ac);
    }
    @Test
    public void testBai3_10() {
        int ex = 600;
        int ac = Bai7.doiThapPhan("257");
        assertEquals(ex, ac);
    }

}
