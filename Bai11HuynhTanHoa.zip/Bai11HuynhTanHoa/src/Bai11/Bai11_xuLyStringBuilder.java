/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_xuLyStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap chuoi sb: ");
        StringBuilder sb = new StringBuilder(input.nextLine());
        System.out.println("Nhap chuoi kt: ");
        StringBuilder kt = new StringBuilder(input.nextLine());
        xuLyStringBuilder(sb, kt);
    }

    static void xuLyStringBuilder(StringBuilder sb, StringBuilder kt) {
        for (int i = 0; i < sb.length(); i++) {
            char kiTu = sb.charAt(i);
            System.out.println("" + kiTu);
        }
        int viTri = -1;
        viTri = sb.indexOf(kt.toString());
        if (viTri == -1) {
        } else {
            System.out.println(kt + " xuat hien tai vi tri " + viTri);
        }

    }
}
