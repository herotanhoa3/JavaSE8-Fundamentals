/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExerciseDay1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Nhap n: ");
        int n = input.nextInt();
        int[] diemSV = new int[n];
        Random random = new Random();
        for (int i = 0; i < diemSV.length; i++) {
            diemSV[i] = random.nextInt(101);
        }
        int tKe0_9 =tkDiem(diemSV, 0, 9), tKe10_19 = tkDiem(diemSV, 10, 19),tKe20_29 = tkDiem(diemSV, 20, 29),
            tKe30_39 = tkDiem(diemSV, 30, 39), tKe40_49 = tkDiem(diemSV, 40, 49),tKe50_59 = tkDiem(diemSV, 50, 59),
            tKe60_69 = tkDiem(diemSV, 60, 69), tKe70_79 = tkDiem(diemSV, 70, 79), tKe80_89 = tkDiem(diemSV, 80, 89), 
            tKe90_100 =tkDiem(diemSV, 90, 100);
            inThongKe(0, 9, tKe0_9);
            inThongKe(10, 19, tKe10_19);
            inThongKe(20, 29, tKe20_29);
            inThongKe(30, 39, tKe30_39);
            inThongKe(40, 49, tKe40_49);
            inThongKe(50, 59, tKe50_59);
            inThongKe(60, 69, tKe60_69);
            inThongKe(70, 79, tKe70_79);
            inThongKe(80, 89, tKe80_89);
            inThongKe(90, 100, tKe90_100);    
    }
    public static int tkDiem(int[] diemSV, int dau, int cuoi) {
        int dem = 0;
        for (int i = 0; i < diemSV.length; i++) {
            if (diemSV[i] >= dau && diemSV[i] <= cuoi) {
                dem++;
            }
        }
        return dem;
    }
    public static void inThongKe(int dau, int cuoi, int dem) {
        System.out.print(dau + " - " + cuoi + ": ");
        for (int i = 0; i < dem; i++) {
            System.out.print("*");
        }
        System.out.println();
        
    }
}
